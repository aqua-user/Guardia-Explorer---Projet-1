# Guardia Explorer

Site scolaire statique en **HTML, CSS et JavaScript simples**, sans Tailwind ni bibliotheque JavaScript.

## Pages

- `accueil/index.html` : accueil, compteur, pass, apercu des evenements et schema du circuit.
- `programme/index.html` : planning filtrable et grille fictive des pilotes.
- `evenements/index.html` : evenements filtrables et reservations gratuites fictives.
- `billetterie/index.html` : parcours en 4 etapes (pass, tribune, informations, confirmation).
- `connexion/index.html` : connexion et case "Je certifie etre un humain".
- `inscription/index.html` : creation de compte et case "Je certifie etre un humain".
- `compte/index.html` : informations personnelles, billets, deconnexion, suppression.
- `admin/index.html` : ajout, modification et suppression d'evenements.

## Fonctionnement

Le site est relie a une base **MySQL 8.4** via une petite API en **PHP** :

- `api/api.php` : toutes les actions (inscription, connexion, billets, evenements, admin). Requetes preparees PDO (anti-injection SQL), mots de passe en bcrypt, session PHP en cookie HttpOnly, prix recalcules cote serveur, role admin verifie cote serveur.
- `api/config.php` : identifiants MySQL (a modifier, jamais accessible depuis le web).
- `api/creer-admin.php` : cree un compte admin, en ligne de commande uniquement.
- `sql/schema.sql` : creation de la base `guardia_explorer` (tables `utilisateurs`, `evenements`, `billets`).
- `deploiement/guardia.conf` : configuration Apache.

Installation et mise en ligne pas a pas : voir **INSTALLATION.md**.

Le site a besoin de PHP : Live Server ou `python3 -m http.server` ne suffisent plus. Pour un test rapide sur Kali : `php -S 127.0.0.1:8000` dans ce dossier (avec MySQL accessible).

## Pour le front (HTML / CSS / JS)

- Chaque page = un dossier (`accueil/`, `evenements/`...) avec `index.html`, `style.css`, `script.js`. Les styles communs sont dans `css/global.css`.
- **Ne pas toucher** : `api/`, `sql/`, `deploiement/` (serveur et base de données). Les donnees passent toutes par `GE.api('action', donnees)` dans `js/common.js`.
- Sans connexion, on peut voir l'accueil, le programme et les evenements. Reserver (evenements, billetterie), le compte et l'admin demandent une connexion : les autres pages renvoient vers `connexion/`.
- Les id HTML utilises par les scripts (ex. `liste-evenements`, `formulaire-billet`) doivent rester identiques, sinon le JavaScript ne trouve plus les elements.
- Apres une modification de CSS ou JS, augmenter le numero de version dans les liens des pages (`style.css?v=4` -> `?v=5`), sinon les navigateurs gardent l'ancienne version.
- Tester sans serveur : ouvrir les pages fonctionne pour le visuel, mais les donnees et la connexion ont besoin du serveur PHP + MySQL (voir INSTALLATION.md) ou du site en ligne.
- Indentation avec de vraies tabulations (`.editorconfig`).

## A savoir

- La case "Je certifie etre un humain" est une simple case a cocher, pas un vrai CAPTCHA.
- Aucun paiement reel ni e-mail n'est envoye.
- L'evenement automobile et tous les pilotes sont fictifs.

## Organisation CSS

- `css/global.css` : couleurs, polices, en-tete, pied de page, boutons, formulaires et composants reutilisables.
- `<page>/style.css` : uniquement les particularites de la page.
- `js/common.js` : appels a l API, compte et fonctions communes.
- `<page>/script.js` : interactions propres a la page.

L'indentation des `.html`, `.css` et `.js` se fait **avec de vraies tabulations**. `.editorconfig` guide VS Code.
