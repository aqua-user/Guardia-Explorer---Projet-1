/* Evenements : filtrer, voir les places restantes et reserver (places limitees, controlees par le serveur). */
let categorie = 'tous';
let mesReservations = new Set(); // ids des evenements deja reserves par l'utilisateur connecte
const liste = document.getElementById('liste-evenements');
const nomsCategories = {concerts:'CONCERT', ateliers:'ATELIER', gaming:'GAMING'};

function blocPlaces(e) {
	const pourcent = e.places ? Math.min(100, Math.round(e.reservees / e.places * 100)) : 100;
	const etat = e.restantes === 0 ? 'complet' : e.restantes <= Math.max(3, e.places * .1) ? 'presque' : '';
	const texte = e.restantes === 0 ? 'COMPLET' : `${e.restantes} PLACE${e.restantes > 1 ? 'S' : ''} RESTANTE${e.restantes > 1 ? 'S' : ''} SUR ${e.places}`;
	return `<div class="places ${etat}"><small class="mono">${texte}</small><div class="jauge" role="progressbar" aria-label="Places reservees" aria-valuemin="0" aria-valuemax="${e.places}" aria-valuenow="${e.reservees}"><span style="width:${pourcent}%"></span></div></div>`;
}
function boutonReserver(e) {
	if (mesReservations.has(e.id)) return `<button class="bouton bouton-petit bouton-clair" disabled>✓ DEJA RESERVE</button>`;
	if (e.restantes === 0) return `<button class="bouton bouton-petit bouton-noir" disabled>COMPLET</button>`;
	return `<button class="bouton bouton-petit reserver" data-id="${GE.propre(e.id)}">RESERVER GRATUITEMENT</button>`;
}
function afficherEvenements() {
	const selection = GE.trierEvenements(GE.cacheEvenements).filter(e => categorie === 'tous' || e.categorie === categorie);
	document.getElementById('aucun-evenement').hidden = selection.length > 0;
	liste.innerHTML = selection.map(e => `
	<article class="carte evenement" id="evenement-${GE.propre(e.id)}">
		<img class="image-carte" src="../images/${GE.propre(e.image)}" alt="Illustration de ${GE.propre(e.titre)}">
		<span class="etiquette ${e.categorie === 'gaming' ? 'etiquette-bleue' : ''}">${nomsCategories[e.categorie] || 'EVENEMENT'}</span>
		<h3>${GE.propre(e.titre)}</h3>
		<div class="horaire">${GE.propre(e.jour)} • ${GE.propre(e.heure)}</div>
		<p>${GE.propre(e.description)}</p>
		${blocPlaces(e)}
		${boutonReserver(e)}
	</article>`).join('');
}
async function charger() {
	// Un visiteur voit les evenements ; ses billets (liste vide) ne servent qu'aux connectes
	const [, billets] = await Promise.all([GE.evenements(), GE.billetsUtilisateur()]);
	mesReservations = new Set(billets.filter(b => b.type === 'activite' && b.evenementId).map(b => b.evenementId));
	afficherEvenements();
	// lien direct vers un evenement (ex. depuis l'accueil) : on le fait defiler a l'ecran
	if (location.hash) document.querySelector(location.hash)?.scrollIntoView({block:'center'});
}

document.querySelectorAll('[data-categorie]').forEach(bouton => bouton.addEventListener('click', () => {
	categorie = bouton.dataset.categorie;
	document.querySelectorAll('[data-categorie]').forEach(b => b.classList.toggle('actif', b === bouton));
	afficherEvenements();
}));

liste.addEventListener('click', async event => {
	const bouton = event.target.closest('.reserver');
	if (!bouton) return;
	const selection = GE.cacheEvenements.find(e => e.id === bouton.dataset.id);
	if (!selection) return;
	// Visiteur non connecte : on l'invite a se connecter, puis il revient sur cette page
	if (!GE.utilisateur()) {
		GE.notification('Connectez-vous pour reserver cette activite.');
		setTimeout(() => location.href = '../connexion/index.html?retour=evenements', 1500);
		return;
	}
	bouton.disabled = true;
	try {
		await GE.reserverActivite(selection);
		GE.notification('Reservation enregistree ! Retrouvez-la dans Mon compte.');
	} catch (erreur) { GE.notification(erreur.message); }
	await charger().catch(() => {}); // met a jour les places restantes
});
GE.pret.then(charger).catch(err => GE.notification(err.message));
