/* Creation de compte (enregistre dans MySQL) */
const formulaire = document.getElementById('formulaire-inscription');
const erreur = document.getElementById('inscription-erreur');
const retour = new URLSearchParams(location.search).get('retour');
if (retour) document.querySelectorAll('a[href="../connexion/index.html"]').forEach(a => a.href += '?retour=' + encodeURIComponent(retour));
GE.pret.then(() => { if (GE.utilisateur()) location.href = GE.pageRetour('accueil'); });

formulaire.addEventListener('submit', async e => {
	e.preventDefault();
	erreur.textContent = '';
	if (document.getElementById('password').value !== document.getElementById('confirmation').value) {
		erreur.textContent = 'Les deux mots de passe ne correspondent pas.';
		return;
	}
	try {
		await GE.inscrire({
			prenom:document.getElementById('prenom').value,
			nom:document.getElementById('nom').value,
			email:document.getElementById('email').value,
			telephone:document.getElementById('telephone').value,
			password:document.getElementById('password').value
		});
		location.href = GE.pageRetour('accueil');
	} catch (err) { erreur.textContent = err.message; }
});
