# Mettre Guardia Explorer en ligne (Proxmox + MySQL + Tailscale Funnel)

Schéma final :

```
Internet ──HTTPS──> Tailscale Funnel ──> conteneur « Site-Ecole » (Proxmox)
                                          ├── Apache + PHP  (le site, port 80)
                                          └── MySQL 8.4     (127.0.0.1:3306, jamais exposé)
```

Toutes les commandes partent de **ton terminal Kali**. Convention :

- `┌──(kali㉿kali)` = commande tapée dans Kali
- `root@pve` = commande tapée sur l'hôte Proxmox (Proxmoxpchd)
- `root@Site-Ecole` = commande tapée **dans** le conteneur MySQL

Les lignes commençant par `#` sont des explications, ne les tape pas.

---

## Étape 1 — Envoyer le zip de Kali vers Proxmox

```bash
# Va dans le dossier où le navigateur a enregistré le zip
# (selon la langue de Kali : ~/Téléchargements ou ~/Downloads)
cd ~/Téléchargements

# scp = copie de fichier par SSH. "root@192.168.1.115" = utilisateur@IP du Proxmox,
# ":/root/" = dossier de destination sur le Proxmox
scp Guardia-Explorer-BDD.zip root@192.168.1.115:/root/

# Connexion en SSH sur l'hôte Proxmox (mot de passe root du Proxmox)
ssh root@192.168.1.115
```

## Étape 2 — Trouver le conteneur et y copier le zip (sur Proxmox)

```bash
# Liste les conteneurs : repère le numéro (VMID) de la ligne « Site-Ecole »
pct list
```

Dans la suite, le numéro de Site-Ecole est **106**.

```bash
# pct push = copie un fichier de l'hôte Proxmox VERS l'intérieur du conteneur
pct push 106 /root/Guardia-Explorer-BDD.zip /root/Guardia-Explorer-BDD.zip
```

## Étape 3 — Autoriser Tailscale dans le conteneur (sur Proxmox)

Un conteneur LXC n'a pas accès par défaut à la carte réseau virtuelle `tun` dont Tailscale a besoin.

```bash
# Ajoute 2 lignes à la fin du fichier de config du conteneur
# (">>" ajoute à la fin, il n'efface rien)
cat >> /etc/pve/lxc/106.conf <<'EOF'
lxc.cgroup2.devices.allow: c 10:200 rwm
lxc.mount.entry: /dev/net/tun dev/net/tun none bind,create=file
EOF

# Redémarre le conteneur pour appliquer, puis entre dedans
pct reboot 106
pct enter 106
```

Ton invite devient `root@Site-Ecole`. Tout ce qui suit se passe **dans le conteneur**.

## Étape 4 — Installer Apache, PHP et décompresser le site

```bash
# Met à jour la liste des paquets puis installe :
#  apache2 = serveur web, libapache2-mod-php = PHP dans Apache,
#  php-mysql = pilote PDO pour parler à MySQL, php-mbstring = gestion des accents, unzip = décompresser
apt update
apt install -y apache2 libapache2-mod-php php-mysql php-mbstring unzip curl

# Décompresse le site dans /var/www/guardia
unzip /root/Guardia-Explorer-BDD.zip -d /root/
mkdir -p /var/www/guardia
cp -r /root/Guardia-Explorer/* /var/www/guardia/

# Donne les fichiers à l'utilisateur d'Apache (www-data)
chown -R www-data:www-data /var/www/guardia
```

## Étape 5 — Créer les tables dans MySQL

D'abord **choisis un mot de passe** pour l'utilisateur MySQL du site (ex. généré avec `openssl rand -base64 18`).

```bash
# Remplace le mot de passe d'exemple dans le fichier SQL ET dans la config PHP
# (sed -i = modifie le fichier sur place ; mets ton mot de passe à la place de MON_MDP)
sed -i "s/ChangeMoi_MotDePasse2026!/MON_MDP/" /root/Guardia-Explorer/sql/schema.sql
sed -i "s/ChangeMoi_MotDePasse2026!/MON_MDP/" /var/www/guardia/api/config.php

# Importe le schéma : crée la base guardia_explorer, les 3 tables, les 11 événements
# et l'utilisateur guardia_app. -p demande le mot de passe root de MySQL.
mysql -u root -p < /root/Guardia-Explorer/sql/schema.sql

# Vérifie : doit afficher 11
mysql -u root -p -e "SELECT COUNT(*) FROM guardia_explorer.evenements;"
```

> Si ton mot de passe contient `/` ou `&`, `sed` va mal le comprendre : choisis-en un avec seulement lettres, chiffres, `-` et `_`.

Crée ensuite **ton compte administrateur** (12 caractères minimum, pas de mot de passe que tu utilises ailleurs) :

```bash
php /var/www/guardia/api/creer-admin.php ton.email@exemple.fr 'UnMotDePasseAdminSolide'
```

## Étape 6 — Configurer Apache

```bash
# Copie la config du site et active les modules utiles
cp /var/www/guardia/deploiement/guardia.conf /etc/apache2/sites-available/guardia.conf
a2enmod headers          # pour les en-têtes de sécurité
a2dissite 000-default    # désactive la page « It works » par défaut
a2ensite guardia         # active notre site

# Teste la config (doit répondre « Syntax OK ») puis recharge Apache
apache2ctl configtest
systemctl reload apache2

# Test local : doit afficher du JSON avec "evenements"
curl -s "http://127.0.0.1/api/api.php?action=evenements" | head -c 200; echo
```

À ce stade, depuis Kali (sur le même réseau), `http://IP_DU_CONTENEUR/` affiche déjà le site.
(Pour connaître l'IP : `hostname -I` dans le conteneur.)

## Étape 7 — Mettre en ligne avec Tailscale Funnel

```bash
# Installe Tailscale (script officiel)
curl -fsSL https://tailscale.com/install.sh | sh

# Connecte le conteneur à ton compte Tailscale sous le nom "guardia-explorer".
# Un lien s'affiche : ouvre-le dans Firefox sur Kali et valide.
tailscale up --hostname=guardia-explorer

# Ouvre le site au public en HTTPS. --bg = reste actif en arrière-plan, même après redémarrage.
tailscale funnel --bg 80
```

La première fois, `tailscale funnel` affiche un lien pour **autoriser Funnel** sur ton compte (console admin Tailscale) : ouvre-le, accepte, puis relance la commande.

```bash
# Affiche l'adresse publique du site
tailscale funnel status
```

Tu obtiens une adresse du type **`https://guardia-explorer.xxxx.ts.net`** : c'est le lien à donner au prof.
Le premier chargement peut prendre ~1 minute (création du certificat HTTPS).

Pour couper l'accès public : `tailscale funnel --bg off` (ou `tailscale funnel reset`).

---

## Mettre à jour le site plus tard

Refais les étapes 1 et 2 avec le nouveau zip, puis dans le conteneur :

```bash
unzip -o /root/Guardia-Explorer-BDD.zip -d /root/
# --exclude garde ta config (et donc ton mot de passe MySQL)
apt install -y rsync
rsync -a --exclude 'api/config.php' /root/Guardia-Explorer/ /var/www/guardia/
chown -R www-data:www-data /var/www/guardia
```

## Migration 2 — statistiques de trafic (si ton site a été installé avant le tableau de bord)

Les nouvelles installations ont déjà la table `visites`. Sur une installation existante, lance une seule fois dans le conteneur :

```bash
# -p demande le mot de passe root de MySQL
mysql -u root -p < /root/Guardia-Explorer/sql/migration-02-visites.sql
```

La mesure d'audience est anonyme : pas de cookie, l'adresse IP n'est jamais enregistrée (seulement une empreinte qui change chaque jour), les robots et les administrateurs ne sont pas comptés.

## Dépannage

| Symptôme | Commande pour voir l'erreur |
|---|---|
| « Base de données indisponible » | `tail -n 20 /var/log/apache2/guardia-erreurs.log` (souvent : mot de passe différent entre `schema.sql` et `config.php`) |
| Page blanche / erreur 500 | même commande que ci-dessus |
| MySQL arrêté | `systemctl status mysql` puis `systemctl start mysql` |
| `tailscale up` : « /dev/net/tun does not exist » | l'étape 3 n'a pas été appliquée ou le conteneur n'a pas redémarré |
| Funnel ne répond pas | `tailscale funnel status` et `systemctl status tailscaled` |

## Voir les données dans MySQL

```bash
mysql -u root -p guardia_explorer
```

```sql
SELECT id, prenom, nom, email, role FROM utilisateurs;
SELECT numero, type, email, total, cree_le FROM billets;
SELECT id, titre, categorie, places FROM evenements;
EXIT;
```

Les mots de passe sont stockés sous forme d'empreinte **bcrypt** (`$2y$…`) : même toi tu ne peux pas les lire, c'est normal.
