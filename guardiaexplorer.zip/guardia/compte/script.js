/* Espace membre : profil, billets, deconnexion et suppression. */
(async () => {
await GE.pret;
let membre = GE.utilisateur();
const panneau = document.getElementById('compte-connecte');
document.getElementById('compte-interdit').hidden = Boolean(membre);
panneau.hidden = !membre;

async function afficherBillets() {
	const liste = document.getElementById('mes-billets');
	const billets = (await GE.billetsUtilisateur()).reverse();
	if (billets.length === 0) {
		liste.innerHTML = '<p class="message">Vous n avez pas encore de billets. <a class="lien-texte" href="../billetterie/index.html">Reserver</a></p>';
		return;
	}
	liste.innerHTML = billets.map(b => `
		<article class="billet"><div><span class="surtitre">${b.type === 'course' ? 'BILLET GRAND PRIX' : 'ACTIVITE FAN VILLAGE'}</span>
		<h3>${GE.propre(b.type === 'course' ? b.nomPass : b.nomEvenement)}</h3>
		<p>${GE.propre(b.id)}<br>${GE.propre(b.type === 'course' ? b.nomTribune : b.dateEvenement)}<br>${GE.date(b.dateCreation)}</p></div>
		<strong>${GE.argent(b.total)}</strong></article>`).join('');
}
if (membre) {
	document.getElementById('bienvenue').textContent = 'BONJOUR ' + membre.prenom.toUpperCase();
	['prenom','nom','email','telephone'].forEach(id => document.getElementById(id).value = membre[id] || '');
	if (membre.role === 'admin') {
		document.getElementById('lien-admin').hidden = false;
		document.getElementById('formulaire-compte').hidden = true;
		document.querySelector('.danger-zone').hidden = true;
	}
	afficherBillets();
}

document.getElementById('deconnexion').addEventListener('click', async () => {
	await GE.deconnecter().catch(() => {});
	location.href = '../connexion/index.html';
});
document.getElementById('formulaire-compte').addEventListener('submit', async e => {
	e.preventDefault();
	const erreur = document.getElementById('compte-erreur');
	erreur.textContent = '';
	try {
		await GE.modifierCompte({
			prenom:document.getElementById('prenom').value.trim(),
			nom:document.getElementById('nom').value.trim(),
			email:document.getElementById('email').value.trim(),
			telephone:document.getElementById('telephone').value.trim()
		});
		membre = GE.utilisateur();
		document.getElementById('bienvenue').textContent = 'BONJOUR ' + membre.prenom.toUpperCase();
		await afficherBillets();
		GE.notification('Vos informations ont ete mises a jour.');
	} catch (err) { erreur.textContent = err.message; }
});
document.getElementById('supprimer-compte').addEventListener('click', async () => {
	if (document.getElementById('mot-suppression').value !== 'SUPPRIMER') {
		GE.notification('Tapez exactement SUPPRIMER pour confirmer.');
		return;
	}
	if (confirm('Confirmer la suppression definitive de ce compte et de ses billets ?')) {
		try {
			await GE.supprimerCompte();
			location.href = '../accueil/index.html';
		} catch (err) { GE.notification(err.message); }
	}
});
})();
