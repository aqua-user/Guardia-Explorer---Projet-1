/* Page programme : onglets et filtre des jours. */
const seances = [
	{jour:'vendredi', heure:'09:00 - 10:30', titre:'Essais libres 1 (FP1)', description:'Mise au point aerodynamique et premiere decouverte de la piste.', type:'ESSAIS'},
	{jour:'vendredi', heure:'14:00 - 15:30', titre:'Essais libres 2 (FP2)', description:'Reglages des monoplaces et simulation de course.', type:'ESSAIS'},
	{jour:'vendredi', heure:'17:00 - 18:00', titre:'Parade des pilotes', description:'Tour d honneur et rencontre avec les supporters au Fan Village.', type:'SHOW'},
	{jour:'samedi', heure:'10:30 - 12:00', titre:'Qualifications sprint', description:'La seance decide de l ordre de depart de la course sprint.', type:'QUALIFS'},
	{jour:'samedi', heure:'14:30 - 15:30', titre:'Course sprint', description:'Quinze tours de course intense sur le circuit urbain.', type:'COURSE'},
	{jour:'samedi', heure:'16:30 - 17:00', titre:'Podium sprint', description:'Remise des trophees et celebrations sur le podium.', type:'PODIUM'},
	{jour:'dimanche', heure:'10:00 - 11:15', titre:'Qualifications officielles', description:'Trois phases de qualifications pour determiner la pole position.', type:'QUALIFS'},
	{jour:'dimanche', heure:'14:30 - 16:00', titre:'Grand Prix Guardia Explorer', description:'La course principale : strategie et depassements.', type:'GRAND PRIX'},
	{jour:'dimanche', heure:'17:00 - 18:00', titre:'Grand podium & Show final', description:'Remise des recompenses et ouverture du festival de cloture.', type:'PODIUM'}
];
const ecuries = [
	{nom:'VELOCE APEX GP', couleur:'#d92b27', pilotes:['Julien Delacroix','Leo Sterling'], num:[7,44]},
	{nom:'SCUDERIA GUARDIA', couleur:'#007c96', pilotes:['Matteo Fontana','Adrien Roussel'], num:[10,11]},
	{nom:'HORIZON GP RACING', couleur:'#ac8745', pilotes:['Kasper Nilsson','Sophie Vandenberg'], num:[23,99]},
	{nom:'CYBER PULSE RACING', couleur:'#6556ac', pilotes:['Yuto Takahashi','Gabriel Santos'], num:[18,81]},
	{nom:'DUNLOP HERITAGE', couleur:'#344d33', pilotes:['Hugo Moreau','Emilia Laurent'], num:[6,14]},
	{nom:'ATLANTIC MOTORSPORT', couleur:'#c15a39', pilotes:['Oscar Bennett','Nina Pereira'], num:[21,33]}
];
const jours = [
	['vendredi','JOUR 01','VENDREDI 14 MAI — ESSAIS & PARADE'],
	['samedi','JOUR 02','SAMEDI 15 MAI — FORMAT SPRINT'],
	['dimanche','JOUR 03','DIMANCHE 16 MAI — GRAND PRIX']
];
let jourCourant = 'tous';
function afficherProgramme() {
	const liste = document.getElementById('planning-list');
	liste.innerHTML = jours.filter(([id]) => jourCourant === 'tous' || id === jourCourant).map(([jour, nombre, titre]) => `
	<section class="jour">
		<div class="jour-titre"><strong>${nombre}</strong><span>${titre}</span></div>
		${seances.filter(s => s.jour === jour).map(s => `
			<article class="session"><strong class="session-heure">${s.heure}</strong><div><h3>${s.titre}</h3><p>${s.description}</p></div><span class="etiquette">${s.type}</span></article>
		`).join('')}
	</section>`).join('');
}
function afficherPilotes() {
	document.getElementById('liste-ecuries').innerHTML = ecuries.map(e => `
	<article class="carte ecurie"><div class="ecurie-bandeau" style="border-top:6px solid ${e.couleur}"><span class="surtitre surtitre-bleu">ECURIE PARTICIPANTE</span><h3>${e.nom}</h3></div>
	<div class="ecurie-contenu">${e.pilotes.map((nom, i) => `<div class="pilote"><div><b>${nom}</b><br><small>PILOTE #${e.num[i]}</small></div><strong>${e.num[i]}</strong></div>`).join('')}</div></article>`).join('');
}

document.querySelectorAll('[data-jour]').forEach(bouton => bouton.addEventListener('click', () => {
	jourCourant = bouton.dataset.jour;
	document.querySelectorAll('[data-jour]').forEach(b => b.classList.toggle('actif', b === bouton));
	afficherProgramme();
}));
function basculerOnglet(voirPilotes) {
	document.getElementById('partie-planning').hidden = voirPilotes;
	document.getElementById('partie-pilotes').hidden = !voirPilotes;
	document.getElementById('onglet-planning').className = 'bouton ' + (voirPilotes ? 'bouton-clair' : 'bouton-noir');
	document.getElementById('onglet-pilotes').className = 'bouton ' + (!voirPilotes ? 'bouton-clair' : 'bouton-noir');
}
document.getElementById('onglet-planning').addEventListener('click', () => basculerOnglet(false));
document.getElementById('onglet-pilotes').addEventListener('click', () => basculerOnglet(true));
afficherProgramme();
afficherPilotes();
