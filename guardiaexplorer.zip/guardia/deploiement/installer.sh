#!/bin/bash
# Installation automatique de Guardia Explorer dans le conteneur (Apache + PHP + MySQL + Tailscale Funnel)
# Lancement : bash /root/Guardia-Explorer/deploiement/installer.sh
set -e
SOURCE="$(cd "$(dirname "$0")/.." && pwd)"
WEB=/var/www/guardia
vert() { echo -e "\n\e[32m==> $1\e[0m"; }
rouge() { echo -e "\n\e[31m!!! $1\e[0m"; }

vert "1/6 Installation d'Apache et PHP"
apt-get update -q
DEBIAN_FRONTEND=noninteractive apt-get install -y -q apache2 libapache2-mod-php php-mysql php-mbstring curl rsync

vert "2/6 Copie du site dans $WEB"
mkdir -p "$WEB"
rsync -a --delete --exclude 'api/config.php' "$SOURCE"/ "$WEB"/

vert "3/6 Base de donnees MySQL"
if mysql -u root -e "SELECT 1" >/dev/null 2>&1; then
	echo "Connexion a MySQL en root sans mot de passe : OK"
else
	read -rsp "Mot de passe ROOT de MySQL (rien ne s'affiche quand tu tapes) : " MYSQL_PWD; echo
	export MYSQL_PWD
	mysql -u root -e "SELECT 1" >/dev/null || { rouge "Mot de passe MySQL incorrect."; exit 1; }
fi
# Mot de passe aleatoire pour l'utilisateur MySQL du site (tu n'as pas besoin de le connaitre)
DBPASS="$(head -c 64 /dev/urandom | base64 | tr -dc A-Za-z0-9 | cut -c1-28)Gx7-"
sed "s/ChangeMoi_MotDePasse2026!/$DBPASS/" "$SOURCE/sql/schema.sql" | mysql -u root
mysql -u root -e "ALTER USER 'guardia_app'@'localhost' IDENTIFIED BY '$DBPASS'; FLUSH PRIVILEGES;"
sed "s/ChangeMoi_MotDePasse2026!/$DBPASS/" "$SOURCE/api/config.php" > "$WEB/api/config.php"
chmod 640 "$WEB/api/config.php"
chown -R www-data:www-data "$WEB"
echo "Evenements dans la base : $(mysql -u root -N -e 'SELECT COUNT(*) FROM guardia_explorer.evenements')"

vert "4/6 Compte administrateur du site"
if [ "$(mysql -u root -N -e "SELECT COUNT(*) FROM guardia_explorer.utilisateurs WHERE role='admin'")" -gt 0 ]; then
	echo "Un compte admin existe deja, on le garde."
else
	until [ -n "$ADMIN_OK" ]; do
		read -rp "E-mail du compte admin : " ADMIN_EMAIL
		read -rsp "Mot de passe admin (12 caracteres min., rien ne s'affiche) : " ADMIN_MDP; echo
		php "$WEB/api/creer-admin.php" "$ADMIN_EMAIL" "$ADMIN_MDP" && ADMIN_OK=1
	done
	unset ADMIN_MDP
fi

vert "5/6 Configuration d'Apache"
cp "$WEB/deploiement/guardia.conf" /etc/apache2/sites-available/guardia.conf
a2enmod -q headers >/dev/null
a2dissite -q 000-default >/dev/null 2>&1 || true
a2ensite -q guardia >/dev/null
apache2ctl configtest
systemctl reload apache2 || systemctl restart apache2
if curl -sf "http://127.0.0.1/api/api.php?action=evenements" | grep -q evenements; then
	echo "Site + base de donnees : OK  (reseau local : http://$(hostname -I | awk '{print $1}')/ )"
else
	rouge "L'API ne repond pas : regarde  tail -n 20 /var/log/apache2/guardia-erreurs.log"; exit 1
fi

[ "$SKIP_TAILSCALE" = 1 ] && exit 0
vert "6/6 Mise en ligne avec Tailscale Funnel"
if [ ! -e /dev/net/tun ]; then
	rouge "/dev/net/tun absent : la config du conteneur (106.conf) n'est pas appliquee. Redemarre le conteneur depuis Proxmox puis relance ce script."
	exit 1
fi
command -v tailscale >/dev/null || curl -fsSL https://tailscale.com/install.sh | sh
echo "Si un lien https://login.tailscale.com/... s'affiche : ouvre-le et valide avec ton compte Tailscale."
tailscale up --hostname=guardia-explorer
echo "Si un lien s'affiche pour ACTIVER Funnel : ouvre-le, accepte, puis relance juste :  tailscale funnel --bg 80"
tailscale funnel --bg 80 || true
tailscale funnel status || true
vert "Termine ! L'adresse publique du site est la ligne https://guardia-explorer....ts.net ci-dessus."
