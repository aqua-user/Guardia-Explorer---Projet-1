/* Panel administrateur : tableau de bord, utilisateurs, billets et evenements (tout vient de MySQL).
   Le serveur verifie le role admin a chaque requete : cacher la page ne suffit pas a proteger. */
(async () => {
await GE.pret;
const moi = GE.utilisateur();
const admin = moi?.role === 'admin';
document.getElementById('admin-refuse').hidden = admin;
document.getElementById('admin-panel').hidden = !admin;
if (!admin) return;

const $ = id => document.getElementById(id);
const dateCourte = texte => new Date(String(texte).replace(' ', 'T')).toLocaleDateString('fr-FR', {day:'2-digit', month:'short', year:'numeric'});

// ---------- Onglets ----------
const chargeurs = {dashboard:afficherDashboard, utilisateurs:chargerUtilisateurs, billets:chargerBillets, evenements:afficherEvenements};
function ouvrirOnglet(nom) {
	document.querySelectorAll('[data-onglet]').forEach(b => b.className = 'bouton bouton-petit ' + (b.dataset.onglet === nom ? 'bouton-noir' : 'bouton-clair'));
	document.querySelectorAll('[data-partie]').forEach(p => p.hidden = p.dataset.partie !== nom);
	try { sessionStorage.setItem('ge_onglet_admin', nom); } catch {}
	chargeurs[nom]().catch(err => GE.notification(err.message));
}
document.querySelectorAll('[data-onglet]').forEach(b => b.addEventListener('click', () => ouvrirOnglet(b.dataset.onglet)));

// ---------- Tableau de bord ----------
const ROUGE = '#d92b27', BLEU = '#0087b8'; // couleurs validees (lisibles aussi pour les daltoniens)
let periode = 30;
try { periode = Number(sessionStorage.getItem('ge_periode_admin')) || 30; } catch {}
const nombre = v => Number(v).toLocaleString('fr-FR');
function barres(liste, total) {
	if (!liste.length) return '<p class="muted">Aucune donnee pour le moment.</p>';
	const max = Math.max(...liste.map(l => Number(l.nombre)));
	return liste.map(l => `<div class="barre-ligne"><span>${GE.propre(l.nom)}</span><b>${nombre(l.nombre)}${total ? ` <small>(${Math.round(l.nombre / total * 100)} %)</small>` : ''}</b>
		<div class="barre"><span style="width:${Math.max(3, Number(l.nombre) / max * 100)}%"></span></div></div>`).join('');
}
function tuile(libelle, valeur, detail, classe = '') {
	return `<div class="tuile ${classe}"><small>${libelle}</small><strong>${GE.propre(valeur)}</strong>${detail ? `<em>${GE.propre(detail)}</em>` : ''}</div>`;
}
const nomsPages = {accueil:'Accueil', programme:'Programme & pilotes', evenements:'Evenements', billetterie:'Billetterie', connexion:'Connexion', inscription:'Inscription', compte:'Mon compte'};
async function afficherDashboard() {
	document.querySelectorAll('[data-jours]').forEach(b => b.className = 'bouton bouton-petit ' + (Number(b.dataset.jours) === periode ? 'bouton-noir' : 'bouton-clair'));
	const [s, t] = await Promise.all([GE.api('admin_stats'), GE.api('admin_trafic&jours=' + periode)]);
	const tot = t.totaux;
	$('migration-requise').hidden = !t.migrationRequise;
	majEnLigne(tot.enLigne);
	const conversion = tot.visiteurs ? (tot.billets / tot.visiteurs * 100).toFixed(1).replace('.', ',') + ' %' : '—';
	$('tuiles').innerHTML = [
		tuile('Visiteurs aujourd\'hui', nombre(tot.visiteursJour), nombre(tot.vuesJour) + ' pages vues'),
		tuile(`Visiteurs (${periode} j)`, nombre(tot.visiteurs), nombre(tot.vues) + ' pages vues', 'bleue'),
		tuile(`Inscriptions (${periode} j)`, nombre(tot.inscriptions), nombre(s.utilisateurs) + ' clients au total'),
		tuile(`Billets vendus (${periode} j)`, nombre(tot.billets), nombre(s.billets) + ' au total', 'bleue'),
		tuile('Taux de conversion', conversion, 'billets / visiteurs'),
		tuile('Recette indicative', GE.argent(s.recette), nombre(s.reservations) + ' reservations d\'activites', 'bleue')
	].join('');

	const jours = t.serie.map(j => j.jour);
	Graphique.courbes($('graph-trafic'), {titre:'Trafic du site', etiquettes:jours, series:[
		{nom:'Pages vues', couleur:ROUGE, valeurs:t.serie.map(j => j.vues), aire:true},
		{nom:'Visiteurs uniques', couleur:BLEU, valeurs:t.serie.map(j => j.visiteurs)}
	]});
	Graphique.barres($('graph-conversions'), {titre:'Inscriptions et billets', etiquettes:jours, series:[
		{nom:'Inscriptions', couleur:BLEU, valeurs:t.serie.map(j => j.inscriptions)},
		{nom:'Billets vendus', couleur:ROUGE, valeurs:t.serie.map(j => j.billets)}
	]});
	Graphique.barres($('graph-recette'), {titre:'Recette par jour', etiquettes:jours, format:v => GE.argent(v), series:[
		{nom:'Recette', couleur:ROUGE, valeurs:t.serie.map(j => j.recette)}
	]});
	$('graph-pages').innerHTML = barres(t.pages.map(p => ({nom:nomsPages[p.nom] || p.nom, nombre:p.nombre})), tot.vues);
	$('graph-sources').innerHTML = barres(t.sources, tot.vues);
	$('graph-appareils').innerHTML = barres(t.appareils.map(a => ({nom:a.nom[0].toUpperCase() + a.nom.slice(1), nombre:a.nombre})), tot.vues);
	$('graph-navigateurs').innerHTML = barres(t.navigateurs, tot.vues);
	const maxH = Math.max(1, ...t.heures);
	$('graph-heures').innerHTML = t.heures.map((v, h) => `<div class="heure" tabindex="0"><div class="heure-col"><span style="height:${v ? Math.max(4, v / maxH * 100) : 0}%"></span></div><small>${h % 3 ? '' : h + 'h'}</small><b>${h} h · ${nombre(v)} vues</b></div>`).join('');
	$('graph-pass').innerHTML = barres(s.parPass);
	$('graph-activites').innerHTML = barres(s.topActivites);
	$('derniers-inscrits').innerHTML = '<thead><tr><th>Nom</th><th>E-mail</th><th>Role</th><th>Inscrit le</th></tr></thead><tbody>' +
		s.derniers.map(u => `<tr><td>${GE.propre(u.prenom)} ${GE.propre(u.nom)}</td><td>${GE.propre(u.email)}</td>
		<td><span class="etiquette ${u.role === 'admin' ? 'etiquette-noire' : 'etiquette-bleue'}">${GE.propre(u.role)}</span></td><td class="mono">${dateCourte(u.cree_le)}</td></tr>`).join('') + '</tbody>';
}
function majEnLigne(n) {
	$('en-ligne').innerHTML = `<i></i> ${nombre(n)} visiteur${n > 1 ? 's' : ''} en ligne`;
	$('en-ligne').classList.toggle('actif', n > 0);
}
document.querySelectorAll('[data-jours]').forEach(b => b.addEventListener('click', () => {
	periode = Number(b.dataset.jours);
	try { sessionStorage.setItem('ge_periode_admin', periode); } catch {}
	afficherDashboard().catch(err => GE.notification(err.message));
}));
// Compteur "en ligne" rafraichi toutes les 30 secondes quand le tableau de bord est affiche
setInterval(() => {
	if (document.hidden || document.querySelector('[data-partie="dashboard"]').hidden) return;
	GE.api('admin_trafic&jours=7').then(t => majEnLigne(t.totaux.enLigne)).catch(() => {});
}, 30000);

// ---------- Utilisateurs ----------
let utilisateurs = [];
async function chargerUtilisateurs() {
	utilisateurs = (await GE.api('admin_utilisateurs')).utilisateurs;
	afficherUtilisateurs();
}
function afficherUtilisateurs() {
	const filtre = $('recherche-utilisateurs').value.trim().toLowerCase();
	const liste = utilisateurs.filter(u => !filtre || [u.prenom, u.nom, u.email, u.telephone].join(' ').toLowerCase().includes(filtre));
	$('liste-utilisateurs').innerHTML = liste.length ? liste.map(u => `<tr>
		<td><b>${GE.propre(u.prenom)} ${GE.propre(u.nom)}</b></td>
		<td>${GE.propre(u.email)}</td>
		<td class="mono">${GE.propre(u.telephone) || '—'}</td>
		<td><span class="etiquette ${u.role === 'admin' ? 'etiquette-noire' : 'etiquette-bleue'}">${GE.propre(u.role)}</span></td>
		<td class="mono">${dateCourte(u.cree_le)}</td>
		<td class="mono">${u.nb_billets}</td>
		<td class="mono">${GE.argent(u.depense)}</td>
		<td><div class="actions">
			<button class="bouton bouton-clair bouton-petit" data-modifier="${u.id}" type="button">MODIFIER</button>
			${u.id === moi.id ? '' : `<button class="bouton bouton-danger bouton-petit" data-supprimer="${u.id}" type="button">SUPPRIMER</button>`}
		</div></td></tr>`).join('') : '<tr><td class="vide" colspan="8">Aucun utilisateur trouve.</td></tr>';
}
$('recherche-utilisateurs').addEventListener('input', afficherUtilisateurs);

const fenetre = $('fenetre-utilisateur');
// u = null : creation d'un nouveau compte ; sinon modification
function ouvrirFenetre(u) {
	$('formulaire-utilisateur').reset();
	$('u-id').value = u ? u.id : '';
	['prenom', 'nom', 'email', 'telephone'].forEach(c => $('u-' + c).value = u ? u[c] || '' : '');
	$('u-role').value = u ? u.role : 'client';
	$('u-role').disabled = Boolean(u) && u.id === moi.id; // on ne peut pas se retirer soi-meme les droits admin
	$('u-password').required = !u;
	$('u-password-label').textContent = u ? 'Nouveau mot de passe (laisser vide pour ne pas changer)' : 'Mot de passe * (8 caracteres min., 12 pour un admin)';
	$('fenetre-surtitre').textContent = u ? 'MODIFIER L UTILISATEUR' : 'NOUVEL UTILISATEUR';
	$('fenetre-titre').textContent = u ? u.prenom + ' ' + u.nom : 'AJOUTER UN COMPTE';
	$('u-erreur').textContent = '';
	fenetre.showModal();
}
document.querySelectorAll('.ajouter-utilisateur').forEach(b => b.addEventListener('click', () => ouvrirFenetre(null)));
$('liste-utilisateurs').addEventListener('click', async event => {
	const modifier = event.target.closest('[data-modifier]');
	const supprimer = event.target.closest('[data-supprimer]');
	if (modifier) {
		const u = utilisateurs.find(x => x.id === modifier.dataset.modifier);
		if (u) ouvrirFenetre(u);
	}
	if (supprimer) {
		const u = utilisateurs.find(x => x.id === supprimer.dataset.supprimer);
		if (!u || !confirm(`Supprimer definitivement ${u.prenom} ${u.nom} (${u.email}) et ses ${u.nb_billets} billet(s) ?`)) return;
		try {
			await GE.api('admin_utilisateur_supprimer', {id:u.id});
			GE.notification('Utilisateur supprime.');
			await chargerUtilisateurs();
		} catch (err) { GE.notification(err.message); }
	}
});
$('u-annuler').addEventListener('click', () => fenetre.close());
$('formulaire-utilisateur').addEventListener('submit', async e => {
	e.preventDefault();
	$('u-erreur').textContent = '';
	try {
		const creation = !$('u-id').value;
		await GE.api(creation ? 'admin_utilisateur_creer' : 'admin_utilisateur_modifier', {
			id:$('u-id').value, prenom:$('u-prenom').value, nom:$('u-nom').value, email:$('u-email').value,
			telephone:$('u-telephone').value, role:$('u-role').value, password:$('u-password').value
		});
		fenetre.close();
		GE.notification(creation ? 'Utilisateur cree.' : 'Utilisateur mis a jour.');
		const onglet = document.querySelector('[data-partie="dashboard"]').hidden ? chargerUtilisateurs : afficherDashboard;
		await onglet();
	} catch (err) { $('u-erreur').textContent = err.message; }
});

// ---------- Billets ----------
let billets = [];
async function chargerBillets() {
	billets = (await GE.api('admin_billets')).billets;
	afficherBillets();
}
function afficherBillets() {
	const filtre = $('recherche-billets').value.trim().toLowerCase();
	const liste = billets.filter(b => !filtre || [b.id, b.email, b.prenom, b.nom, b.nomPass, b.nomTribune, b.nomEvenement].join(' ').toLowerCase().includes(filtre));
	$('liste-billets').innerHTML = liste.length ? liste.map(b => `<tr>
		<td class="mono">${GE.propre(b.id)}</td>
		<td><span class="etiquette ${b.type === 'course' ? '' : 'etiquette-bleue'}">${b.type === 'course' ? 'Grand Prix' : 'Activite'}</span></td>
		<td>${GE.propre(b.prenom)} ${GE.propre(b.nom)}</td>
		<td>${GE.propre(b.email)}</td>
		<td>${GE.propre(b.type === 'course' ? b.nomPass + ' · ' + b.nomTribune : b.nomEvenement)}</td>
		<td class="mono">${GE.argent(b.total)}</td>
		<td class="mono">${dateCourte(b.dateCreation)}</td>
		<td><div class="actions"><button class="bouton bouton-danger bouton-petit" data-billet="${GE.propre(b.id)}" type="button">ANNULER</button></div></td>
	</tr>`).join('') : '<tr><td class="vide" colspan="8">Aucun billet trouve.</td></tr>';
}
$('recherche-billets').addEventListener('input', afficherBillets);
$('liste-billets').addEventListener('click', async event => {
	const bouton = event.target.closest('[data-billet]');
	if (!bouton || !confirm('Annuler (supprimer) le billet ' + bouton.dataset.billet + ' ?')) return;
	try {
		await GE.api('admin_billet_supprimer', {numero:bouton.dataset.billet});
		GE.notification('Billet supprime.');
		await chargerBillets();
	} catch (err) { GE.notification(err.message); }
});

// ---------- Evenements ----------
const form = $('formulaire-admin');
const champs = {
	id:$('event-id'), titre:$('event-titre'), categorie:$('event-categorie'), jour:$('event-jour'),
	heure:$('event-heure'), places:$('event-places'), description:$('event-description')
};
function reinitialiser() {
	form.reset();
	champs.id.value = '';
	$('titre-formulaire').textContent = 'AJOUTER UN EVENEMENT';
}
let dernierEnregistre = null; // id de l'evenement qu'on vient d'ajouter / modifier
async function afficherEvenements() {
	// les plus recents en premier : un evenement ajoute apparait en haut de la liste
	const evenements = [...await GE.evenements()].sort((a, b) => Number(b.id) - Number(a.id));
	$('nombre-evenements').textContent = evenements.length;
	$('admin-liste').innerHTML = evenements.map(e => `
		<article class="admin-event${e.id === dernierEnregistre ? ' tout-juste' : ''}" id="admin-evt-${GE.propre(e.id)}"><div><span class="etiquette">${GE.propre(e.categorie)}</span>${e.restantes === 0 ? ' <span class="etiquette etiquette-noire">COMPLET</span>' : ''}<h3>${GE.propre(e.titre)}</h3><p>${GE.propre(e.jour)} • ${GE.propre(e.heure)} • <b>${e.reservees} / ${e.places}</b> PLACES RESERVEES</p></div>
		<div class="formulaire-actions"><button class="bouton bouton-clair bouton-petit modifier" data-id="${GE.propre(e.id)}">MODIFIER</button><button class="bouton bouton-danger bouton-petit supprimer" data-id="${GE.propre(e.id)}">SUPPRIMER</button></div></article>`).join('');
}
form.addEventListener('submit', async e => {
	e.preventDefault();
	const valeurs = {
		id:champs.id.value || null, titre:champs.titre.value.trim(), categorie:champs.categorie.value,
		jour:champs.jour.value.trim(), heure:champs.heure.value.trim(), places:Number(champs.places.value),
		description:champs.description.value.trim()
	};
	if (!valeurs.titre || !valeurs.jour || !valeurs.heure || !valeurs.description || valeurs.places < 1) return;
	try {
		const r = await GE.sauverEvenement(valeurs);
		dernierEnregistre = r.id;
		reinitialiser();
		await afficherEvenements();
		$('admin-evt-' + r.id)?.scrollIntoView({behavior:'smooth', block:'center'});
		GE.notification(valeurs.id ? 'Evenement modifie.' : 'Evenement ajoute : il est visible sur la page Evenements.');
	} catch (err) { GE.notification(err.message); }
});
$('annuler-modif').addEventListener('click', reinitialiser);
$('admin-liste').addEventListener('click', async event => {
	const bouton = event.target.closest('button[data-id]');
	if (!bouton) return;
	const element = GE.cacheEvenements.find(item => item.id === bouton.dataset.id);
	if (!element) return;
	if (bouton.classList.contains('supprimer')) {
		if (!confirm('Supprimer cet evenement du catalogue ?')) return;
		try {
			await GE.supprimerEvenement(element.id);
			if (champs.id.value === element.id) reinitialiser();
			await afficherEvenements();
			GE.notification('Evenement supprime.');
		} catch (err) { GE.notification(err.message); }
		return;
	}
	for (const nom in champs) champs[nom].value = element[nom] ?? '';
	$('titre-formulaire').textContent = 'MODIFIER L EVENEMENT';
	window.scrollTo({top:0, behavior:'smooth'});
});

let depart = 'dashboard';
try { depart = sessionStorage.getItem('ge_onglet_admin') || depart; } catch {}
ouvrirOnglet(chargeurs[depart] ? depart : 'dashboard');
})();
