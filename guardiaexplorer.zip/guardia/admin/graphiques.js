/* Petits graphiques SVG sans bibliotheque : courbes et barres groupees, avec infobulle au survol.
   Utilisation : Graphique.courbes(element, {etiquettes, series:[{nom, couleur, valeurs}], format})
                 Graphique.barres(element, {...meme chose...}) */
const Graphique = (() => {
	const NS = 'http://www.w3.org/2000/svg';
	const HAUTEUR = 240, MARGE = {haut:12, droite:12, bas:28, gauche:44};

	function svg(nom, attributs, parent) {
		const el = document.createElementNS(NS, nom);
		for (const a in attributs) el.setAttribute(a, attributs[a]);
		if (parent) parent.appendChild(el);
		return el;
	}
	// Maximum "rond" pour l'axe vertical (1, 2, 5, 10, 20, 50...)
	// 4 graduations a pas entier et "rond" : 0, 3, 6, 9, 12 ou 0, 80, 160, 240, 320...
	function maxRond(v) {
		if (v <= 4) return 4;
		const brut = v / 4, p = Math.pow(10, Math.floor(Math.log10(brut)));
		const pas = [1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10].map(m => m * p).find(m => m >= brut && Number.isInteger(m));
		return pas * 4;
	}
	const formatJour = iso => new Date(iso + 'T12:00:00').toLocaleDateString('fr-FR', {day:'numeric', month:'short'});

	function legende(conteneur, series, forme) {
		const div = document.createElement('div');
		div.className = 'graph-legende';
		series.forEach(s => {
			const item = document.createElement('span');
			const cle = document.createElement('i');
			cle.className = forme === 'barre' ? 'cle-barre' : 'cle-ligne';
			cle.style.background = s.couleur;
			item.append(cle, document.createTextNode(s.nom));
			div.appendChild(item);
		});
		conteneur.appendChild(div);
	}

	function tableau(conteneur, etiquettes, series, format) {
		const details = document.createElement('details');
		details.className = 'graph-donnees';
		const resume = document.createElement('summary');
		resume.textContent = 'Voir les donnees en tableau';
		const table = document.createElement('table');
		table.className = 'tableau';
		const ligneTitre = table.createTHead().insertRow();
		['Jour', ...series.map(s => s.nom)].forEach(t => { const th = document.createElement('th'); th.textContent = t; ligneTitre.appendChild(th); });
		const corps = table.createTBody();
		etiquettes.forEach((e, i) => {
			const l = corps.insertRow();
			l.insertCell().textContent = formatJour(e);
			series.forEach(s => { const c = l.insertCell(); c.className = 'mono'; c.textContent = format(s.valeurs[i]); });
		});
		details.append(resume, table);
		conteneur.appendChild(details);
	}

	function dessiner(conteneur, options, type) {
		const {etiquettes, series} = options;
		const format = options.format || (v => Number(v).toLocaleString('fr-FR'));
		conteneur.innerHTML = '';
		if (series.length > 1) legende(conteneur, series, type === 'barres' ? 'barre' : 'ligne');
		const zone = document.createElement('div');
		zone.className = 'graph-zone';
		conteneur.appendChild(zone);
		const largeur = Math.max(280, zone.clientWidth);
		const l = largeur - MARGE.gauche - MARGE.droite, h = HAUTEUR - MARGE.haut - MARGE.bas;
		const max = maxRond(Math.max(1, ...series.flatMap(s => s.valeurs)));
		const y = v => MARGE.haut + h - (v / max) * h;
		const n = etiquettes.length;
		const pas = type === 'barres' ? l / n : l / Math.max(1, n - 1);
		const x = i => type === 'barres' ? MARGE.gauche + pas * (i + .5) : MARGE.gauche + pas * i;

		const racine = svg('svg', {width:largeur, height:HAUTEUR, viewBox:`0 0 ${largeur} ${HAUTEUR}`, role:'img', 'aria-label':options.titre || 'Graphique'}, zone);
		// grille et axe vertical (discrets)
		for (let k = 0; k <= 4; k++) {
			const v = max / 4 * k, yy = y(v);
			svg('line', {x1:MARGE.gauche, x2:largeur - MARGE.droite, y1:yy, y2:yy, class:k ? 'graph-grille' : 'graph-axe'}, racine);
			svg('text', {x:MARGE.gauche - 8, y:yy + 4, 'text-anchor':'end', class:'graph-texte'}, racine).textContent = format(v);
		}
		// dates en bas (environ 6 reperes)
		const tous = Math.max(1, Math.ceil(n / 6));
		etiquettes.forEach((e, i) => {
			if (i % tous && i !== n - 1) return;
			svg('text', {x:x(i), y:HAUTEUR - 8, 'text-anchor':'middle', class:'graph-texte'}, racine).textContent = formatJour(e);
		});

		if (type === 'barres') {
			const groupe = Math.min(28, pas * .75), largeurBarre = Math.max(2, groupe / series.length - 2);
			series.forEach((s, j) => s.valeurs.forEach((v, i) => {
				if (!v) return;
				const bx = x(i) - groupe / 2 + j * (largeurBarre + 2), by = y(v), bh = MARGE.haut + h - by;
				const r = Math.min(4, largeurBarre / 2, bh);
				// barre aux coins hauts arrondis, posee sur l'axe
				svg('path', {d:`M${bx},${by + bh} V${by + r} Q${bx},${by} ${bx + r},${by} H${bx + largeurBarre - r} Q${bx + largeurBarre},${by} ${bx + largeurBarre},${by + r} V${by + bh} Z`, fill:s.couleur}, racine);
			}));
		} else {
			series.forEach(s => {
				const points = s.valeurs.map((v, i) => `${x(i)},${y(v)}`).join(' ');
				if (s.aire) svg('polygon', {points:`${x(0)},${y(0)} ${points} ${x(n - 1)},${y(0)}`, fill:s.couleur, opacity:.08}, racine);
				svg('polyline', {points, fill:'none', stroke:s.couleur, 'stroke-width':2, 'stroke-linejoin':'round', 'stroke-linecap':'round'}, racine);
			});
		}

		// Survol : ligne verticale + infobulle avec toutes les series du jour
		const repere = svg('line', {y1:MARGE.haut, y2:MARGE.haut + h, class:'graph-repere', visibility:'hidden'}, racine);
		const points = series.map(s => svg('circle', {r:4.5, fill:s.couleur, stroke:'#fff', 'stroke-width':2, visibility:'hidden'}, racine));
		const bulle = document.createElement('div');
		bulle.className = 'graph-bulle';
		bulle.hidden = true;
		zone.appendChild(bulle);
		const capteur = svg('rect', {x:MARGE.gauche, y:0, width:l, height:HAUTEUR, fill:'transparent', tabindex:0}, racine);
		function montrer(i) {
			repere.setAttribute('x1', x(i)); repere.setAttribute('x2', x(i)); repere.setAttribute('visibility', 'visible');
			points.forEach((p, j) => {
				const visible = type !== 'barres';
				p.setAttribute('cx', x(i)); p.setAttribute('cy', y(series[j].valeurs[i])); p.setAttribute('visibility', visible ? 'visible' : 'hidden');
			});
			bulle.replaceChildren();
			const titre = document.createElement('b');
			titre.textContent = formatJour(etiquettes[i]);
			bulle.appendChild(titre);
			series.forEach(s => {
				const ligne = document.createElement('div');
				const cle = document.createElement('i'); cle.style.background = s.couleur;
				const valeur = document.createElement('strong'); valeur.textContent = format(s.valeurs[i]);
				const nom = document.createElement('span'); nom.textContent = s.nom;
				ligne.append(cle, valeur, nom);
				bulle.appendChild(ligne);
			});
			bulle.hidden = false;
			const gauche = x(i) + 14 + bulle.offsetWidth > largeur ? x(i) - 14 - bulle.offsetWidth : x(i) + 14;
			bulle.style.left = gauche + 'px';
		}
		function cacher() { repere.setAttribute('visibility', 'hidden'); points.forEach(p => p.setAttribute('visibility', 'hidden')); bulle.hidden = true; }
		let courant = n - 1;
		capteur.addEventListener('pointermove', e => {
			const rect = racine.getBoundingClientRect();
			const px = e.clientX - rect.left;
			courant = Math.max(0, Math.min(n - 1, Math.round(type === 'barres' ? (px - MARGE.gauche) / pas - .5 : (px - MARGE.gauche) / pas)));
			montrer(courant);
		});
		capteur.addEventListener('pointerleave', cacher);
		capteur.addEventListener('focus', () => montrer(courant));
		capteur.addEventListener('blur', cacher);
		capteur.addEventListener('keydown', e => {
			if (e.key === 'ArrowLeft') courant = Math.max(0, courant - 1);
			else if (e.key === 'ArrowRight') courant = Math.min(n - 1, courant + 1);
			else return;
			e.preventDefault(); montrer(courant);
		});

		tableau(conteneur, etiquettes, series, format);
	}

	// Redessine quand la fenetre change de taille
	const dessines = new Map();
	let minuterie;
	window.addEventListener('resize', () => {
		clearTimeout(minuterie);
		minuterie = setTimeout(() => dessines.forEach(([o, t], el) => { if (el.isConnected && el.offsetParent) dessiner(el, o, t); }), 150);
	});
	const enregistrer = type => (el, options) => { dessines.set(el, [options, type]); dessiner(el, options, type); };
	return {courbes:enregistrer('courbes'), barres:enregistrer('barres')};
})();
