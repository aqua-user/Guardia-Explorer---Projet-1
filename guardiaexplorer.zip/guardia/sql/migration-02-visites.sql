-- Migration 2 : table des visites (statistiques de trafic du tableau de bord)
-- A lancer une seule fois : mysql -u root -p < migration-02-visites.sql
USE guardia_explorer;

CREATE TABLE IF NOT EXISTS visites (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	visiteur CHAR(16) NOT NULL,                  -- empreinte anonyme du jour (l'adresse IP n'est jamais stockee)
	page VARCHAR(40) NOT NULL,
	source VARCHAR(120) NOT NULL DEFAULT 'Direct',
	appareil ENUM('ordinateur','mobile','tablette') NOT NULL DEFAULT 'ordinateur',
	navigateur VARCHAR(20) NOT NULL DEFAULT 'Autre',
	cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	INDEX idx_visites_date (cree_le),
	INDEX idx_visites_visiteur (visiteur)
) ENGINE=InnoDB;
