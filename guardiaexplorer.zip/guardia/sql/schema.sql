-- Guardia Explorer : creation de la base de donnees
-- A importer dans MySQL 8.4 avec : mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS guardia_explorer
	CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE guardia_explorer;

-- Comptes des visiteurs et des administrateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	prenom VARCHAR(80) NOT NULL,
	nom VARCHAR(80) NOT NULL,
	email VARCHAR(190) NOT NULL UNIQUE,
	telephone VARCHAR(30) NOT NULL DEFAULT '',
	mot_de_passe VARCHAR(255) NOT NULL,          -- empreinte bcrypt (password_hash en PHP)
	role ENUM('client','admin') NOT NULL DEFAULT 'client',
	cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Evenements du Fan Village (geres depuis la page admin)
CREATE TABLE IF NOT EXISTS evenements (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	categorie ENUM('concerts','ateliers','gaming') NOT NULL,
	titre VARCHAR(150) NOT NULL,
	jour VARCHAR(60) NOT NULL,
	heure VARCHAR(40) NOT NULL,
	places INT UNSIGNED NOT NULL,
	description TEXT NOT NULL,
	image VARCHAR(100) NOT NULL DEFAULT 'evenement-photo-5.jpg'
) ENGINE=InnoDB;

-- Billets : place pour le Grand Prix (type 'course') ou reservation d'activite (type 'activite')
CREATE TABLE IF NOT EXISTS billets (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	numero VARCHAR(20) NOT NULL UNIQUE,          -- ex : GE-M3K9X2AB
	type ENUM('course','activite') NOT NULL,
	email VARCHAR(190) NOT NULL,                 -- relie le billet au compte ayant ce meme e-mail
	prenom VARCHAR(80) NOT NULL,
	nom VARCHAR(80) NOT NULL,
	telephone VARCHAR(30) NOT NULL DEFAULT '',
	pass_id VARCHAR(20) NULL,
	nom_pass VARCHAR(80) NULL,
	tribune_id VARCHAR(20) NULL,
	nom_tribune VARCHAR(80) NULL,
	prix_pass DECIMAL(8,2) NOT NULL DEFAULT 0,
	prix_tribune DECIMAL(8,2) NOT NULL DEFAULT 0,
	evenement_id INT UNSIGNED NULL,
	nom_evenement VARCHAR(150) NULL,
	date_evenement VARCHAR(110) NULL,
	total DECIMAL(8,2) NOT NULL DEFAULT 0,
	cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	INDEX idx_billets_email (email),
	CONSTRAINT fk_billets_evenement FOREIGN KEY (evenement_id)
		REFERENCES evenements(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Visites du site (statistiques de trafic, anonymes)
CREATE TABLE IF NOT EXISTS visites (
	id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	visiteur CHAR(16) NOT NULL,                  -- empreinte anonyme du jour (l'adresse IP n'est jamais stockee)
	page VARCHAR(40) NOT NULL,
	source VARCHAR(120) NOT NULL DEFAULT 'Direct',
	appareil ENUM('ordinateur','mobile','tablette') NOT NULL DEFAULT 'ordinateur',
	navigateur VARCHAR(20) NOT NULL DEFAULT 'Autre',
	cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	INDEX idx_visites_date (cree_le),
	INDEX idx_visites_visiteur (visiteur)
) ENGINE=InnoDB;

-- Evenements de depart (seulement si la table est vide)
INSERT INTO evenements (categorie, titre, jour, heure, places, description, image)
SELECT * FROM (
	SELECT 'concerts' AS c, 'Grand Show Electro / Rock Sunset' AS t, 'Vendredi 14 mai' AS j, '20h30' AS h, 5000 AS p, 'Un concert electro-rock au bord des quais, entre lumieres et moteurs.' AS d, 'evenement-photo-1.jpg' AS i
	UNION ALL SELECT 'concerts', 'The Sound of Motors : Symphonie', 'Samedi 15 mai', '21h30', 280, 'Un orchestre symphonique interprete les grandes musiques de course.', 'evenement-photo-2.jpg'
	UNION ALL SELECT 'concerts', 'After-Race Festival & Podium', 'Dimanche 16 mai', '18h00', 2500, 'DJ set, podium final, musique et celebration du Grand Prix.', 'evenement-photo-3.jpg'
	UNION ALL SELECT 'ateliers', 'Initiation Pit-Stop Chronometre', 'Samedi 15 mai', '11h00', 90, 'Testez le changement de roue sur un chassis d entrainement.', 'evenement-photo-5.jpg'
	UNION ALL SELECT 'ateliers', 'Masterclass Photographie Sportive', 'Samedi 15 mai', '14h00', 36, 'Apprenez le file photographique avec des professionnels.', 'evenement-photo-5.jpg'
	UNION ALL SELECT 'ateliers', 'Atelier Affiches Vintage', 'Vendredi 14 mai', '16h00', 100, 'Creez votre poster souvenir Guardia Explorer.', 'evenement-photo-5.jpg'
	UNION ALL SELECT 'ateliers', 'FabLab & Mini-Soufflerie', 'Dimanche 16 mai', '10h00', 80, 'Decouvrez le fonctionnement aerodynamique d une monoplace.', 'evenement-photo-5.jpg'
	UNION ALL SELECT 'ateliers', 'Gastronomie Regionale', 'Samedi 15 mai', '12h00', 70, 'Rencontrez les artisans et producteurs de la region.', 'evenement-photo-5.jpg'
	UNION ALL SELECT 'gaming', 'Arena Sim-Racing & VR', 'Tout le week-end', '10h - 19h', 600, 'Pilotez le circuit de Bordeaux avec volant, pedales et casque VR.', 'evenement-photo-4.jpg'
	UNION ALL SELECT 'gaming', 'Challenge Chrono Esport', 'Samedi 15 mai', '15h00', 120, 'Affrontez les meilleurs temps sur simulateur.', 'evenement-photo-4.jpg'
	UNION ALL SELECT 'gaming', 'Expo Bolides & Technologie', 'Tout le week-end', '10h - 18h', 1000, 'Une exposition de monoplaces, moteurs et innovations.', 'evenement-photo-5.jpg'
) AS depart
WHERE NOT EXISTS (SELECT 1 FROM evenements);

-- Utilisateur MySQL dedie au site (droits limites a cette base).
-- REMPLACEZ le mot de passe ci-dessous, et mettez le meme dans api/config.php
CREATE USER IF NOT EXISTS 'guardia_app'@'localhost' IDENTIFIED BY 'ChangeMoi_MotDePasse2026!';
GRANT SELECT, INSERT, UPDATE, DELETE ON guardia_explorer.* TO 'guardia_app'@'localhost';
FLUSH PRIVILEGES;
