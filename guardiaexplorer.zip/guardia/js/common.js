/* Fonctions partagees du site. Les donnees sont lues et ecrites dans MySQL via api/api.php. */
const GE = {
	dateCourse: '2027-05-16T14:30:00',
	moi: null,          // utilisateur connecte (charge au demarrage de chaque page)
	cacheEvenements: [],

	// Appel a l'API PHP. GET si pas de donnees, sinon POST en JSON.
	async api(action, donnees) {
		const options = {credentials:'same-origin', headers:{}};
		if (donnees !== undefined) {
			options.method = 'POST';
			options.headers['Content-Type'] = 'application/json';
			options.headers['X-Guardia'] = '1';
			options.body = JSON.stringify(donnees);
		}
		let reponse;
		try { reponse = await fetch('../api/api.php?action=' + action, options); }
		catch { throw new Error('Serveur injoignable. Verifiez votre connexion.'); }
		const json = await reponse.json().catch(() => ({erreur:'Reponse invalide du serveur.'}));
		if (!reponse.ok) throw new Error(json.erreur || 'Erreur ' + reponse.status);
		return json;
	},
	async charger() {
		try { this.moi = (await this.api('moi')).utilisateur; }
		catch { this.moi = null; }
		return this.moi;
	},

	propre(texte) {
		return String(texte ?? '').replace(/[&<>"']/g, caractere => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[caractere]));
	},
	argent(montant) { return Number(montant).toLocaleString('fr-FR', {style:'currency', currency:'EUR', maximumFractionDigits:0}); },
	date(texte) { return new Date(texte).toLocaleString('fr-FR', {dateStyle:'medium', timeStyle:'short'}); },

	// Ordre chronologique : vendredi, samedi, dimanche, puis "tout le week-end", puis l'heure
	trierEvenements(liste) {
		const rangJour = j => { const t = String(j).toLowerCase(); return t.includes('vendredi') ? 1 : t.includes('samedi') ? 2 : t.includes('dimanche') ? 3 : 4; };
		const minutes = h => { const m = String(h).match(/(\d{1,2})\s*h\s*(\d{0,2})/i); return m ? Number(m[1]) * 60 + Number(m[2] || 0) : 9999; };
		return [...liste].sort((a, b) => rangJour(a.jour) - rangJour(b.jour) || minutes(a.heure) - minutes(b.heure) || Number(a.id) - Number(b.id));
	},
	async evenements() {
		this.cacheEvenements = (await this.api('evenements')).evenements;
		return this.cacheEvenements;
	},
	sauverEvenement(evenement) { return this.api('evenement_sauver', evenement); },
	supprimerEvenement(id) { return this.api('evenement_supprimer', {id}); },

	utilisateur() { return this.moi; },
	async inscrire(info) {
		this.moi = (await this.api('inscription', info)).utilisateur;
		return this.moi;
	},
	async connecter(email, password) {
		this.moi = (await this.api('connexion', {email, password})).utilisateur;
		return this.moi;
	},
	async deconnecter() { await this.api('deconnexion', {}); this.moi = null; },
	async modifierCompte(changements) {
		this.moi = (await this.api('modifier_compte', changements)).utilisateur;
		return true;
	},
	async supprimerCompte() { await this.api('supprimer_compte', {}); this.moi = null; return true; },
	async billetsUtilisateur() { return (await this.api('mes_billets')).billets; },
	reserverActivite(evenement) { return this.api('reserver_activite', {evenementId:evenement.id}); },
	// Page ou revenir apres connexion / inscription (liste fermee : pas de redirection vers un autre site)
	pageRetour(defaut) {
		const r = new URLSearchParams(location.search).get('retour');
		const pages = ['accueil', 'programme', 'evenements', 'billetterie', 'compte', 'admin'];
		return '../' + (pages.includes(r) ? r : defaut) + '/index.html';
	},
	notification(message) {
		const ancienne = document.querySelector('.notification');
		if (ancienne) ancienne.remove();
		const div = document.createElement('div');
		div.className = 'notification';
		div.setAttribute('role', 'status');
		div.textContent = message;
		document.body.appendChild(div);
		setTimeout(() => div.remove(), 3800);
	}
};

// Nom de la page courante (dossier) : accueil, evenements, connexion...
GE.page = location.pathname.split('/').filter(seg => seg && !seg.includes('.')).pop() || 'accueil';
GE.pagesPubliques = [
	'accueil',
	'programme',
	'evenements',
	'connexion',
	'inscription'
];

// Chargement de l'utilisateur connecte : chaque page attend "GE.pret" avant de s'afficher.
GE.pret = GE.charger();

// Site reserve aux membres : sans connexion, toute page (sauf connexion / inscription) renvoie vers la connexion.
GE.pret.then(u => {
	if (!u && !GE.pagesPubliques.includes(GE.page)) location.replace('../connexion/index.html?retour=' + encodeURIComponent(GE.page));
	else document.documentElement.classList.remove('verif-session');
});

// Navigation mobile, lien de compte et formulaire de newsletter.
document.addEventListener('DOMContentLoaded', async () => {
	const menu = document.getElementById('menu-bouton');
	const nav = document.getElementById('navigation');
	if (menu && nav) menu.addEventListener('click', () => {
		const ouvert = nav.classList.toggle('ouverte');
		menu.setAttribute('aria-expanded', String(ouvert));
	});
	const compte = document.getElementById('lien-compte');
	await GE.pret;
	if (compte && GE.utilisateur()) compte.href = '../compte/index.html';

	// Lien DASHBOARD dans le menu, visible uniquement pour les administrateurs
	const page = GE.page;
	if (nav && GE.utilisateur()?.role === 'admin') {
		const lien = document.createElement('a');
		lien.href = '../admin/index.html';
		lien.textContent = 'DASHBOARD';
		lien.className = 'lien-dashboard' + (page === 'admin' ? ' actif' : '');
		if (page === 'admin') lien.setAttribute('aria-current', 'page');
		nav.appendChild(lien);
	}
	// Mesure d'audience anonyme (pas de cookie ; le serveur ignore les admins et les robots)
	if (page !== 'admin' && (GE.utilisateur() || GE.pagesPubliques.includes(page))) GE.api('visite', {page, referrer:document.referrer}).catch(() => {});
	const news = document.getElementById('newsletter');
	if (news) news.addEventListener('submit', e => {
		e.preventDefault();
		GE.notification('Merci ! La newsletter n est pas encore active.');
	});
});
