<?php
// Parametres de connexion a MySQL. Le site et MySQL sont dans le meme conteneur,
// donc on se connecte en local (127.0.0.1). Mettez ici le mot de passe choisi dans schema.sql.
return [
	'hote'         => '127.0.0.1',
	'port'         => 3306,
	'base'         => 'guardia_explorer',
	'utilisateur'  => 'guardia_app',
	'mot_de_passe' => 'ZlWyRwGgGw05n3qFQX6UgSkwUStFGx7-',
];
