<?php
/*
 * Cree (ou remet a jour) un compte administrateur.
 * A lancer UNIQUEMENT en ligne de commande dans le conteneur :
 *   php /var/www/guardia/api/creer-admin.php admin@exemple.fr 'MotDePasseSolide'
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if ($argc !== 3) { fwrite(STDERR, "Usage : php creer-admin.php EMAIL MOT_DE_PASSE\n"); exit(1); }
[$script, $email, $mdp] = $argv;
$email = strtolower(trim($email));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { fwrite(STDERR, "E-mail invalide.\n"); exit(1); }
if (strlen($mdp) < 12) { fwrite(STDERR, "Mot de passe trop court (12 caracteres minimum pour l'admin).\n"); exit(1); }

$c = require __DIR__ . '/config.php';
$pdo = new PDO("mysql:host={$c['hote']};port={$c['port']};dbname={$c['base']};charset=utf8mb4",
	$c['utilisateur'], $c['mot_de_passe'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$pdo->prepare("INSERT INTO utilisateurs (prenom, nom, email, mot_de_passe, role) VALUES ('Admin', 'Guardia', ?, ?, 'admin')
	ON DUPLICATE KEY UPDATE mot_de_passe = VALUES(mot_de_passe), role = 'admin'")
	->execute([$email, password_hash($mdp, PASSWORD_DEFAULT)]);
echo "Compte administrateur pret : $email\n";
