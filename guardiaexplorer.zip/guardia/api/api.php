<?php
/*
 * API du site Guardia Explorer : fait le lien entre les pages (JavaScript) et MySQL.
 * Appel : api/api.php?action=NOM  (GET pour lire, POST + JSON pour modifier)
 * Reponse : toujours du JSON. En cas d'erreur : {"erreur": "message"} avec un code HTTP 4xx/5xx.
 */
declare(strict_types=1);
date_default_timezone_set('Europe/Paris');

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

// ---------- Session (cookie de connexion) ----------
$https = ($_SERVER['HTTPS'] ?? '') === 'on' || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'
	|| str_ends_with($_SERVER['HTTP_HOST'] ?? '', '.ts.net'); // Tailscale Funnel = toujours HTTPS
session_set_cookie_params([
	'lifetime' => 0,
	'path'     => '/',
	'secure'   => $https,
	'httponly' => true,      // inaccessible au JavaScript (protege contre le vol de session par XSS)
	'samesite' => 'Lax',
]);
session_name('GESESSION');
session_start();

// ---------- Petites fonctions utiles ----------
function repondre($donnees, int $code = 200): never {
	http_response_code($code);
	echo json_encode($donnees, JSON_UNESCAPED_UNICODE);
	exit;
}
function erreur(string $message, int $code = 400): never {
	repondre(['erreur' => $message], $code);
}
function bdd(): PDO {
	static $pdo = null;
	if ($pdo === null) {
		$c = require __DIR__ . '/config.php';
		try {
			$pdo = new PDO(
				"mysql:host={$c['hote']};port={$c['port']};dbname={$c['base']};charset=utf8mb4",
				$c['utilisateur'], $c['mot_de_passe'],
				[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
			);
			$pdo->exec("SET time_zone = '" . date('P') . "'"); // meme fuseau que PHP (heure de Paris)
		} catch (PDOException $e) {
			error_log('Connexion MySQL impossible : ' . $e->getMessage());
			erreur('Base de donnees indisponible.', 503);
		}
	}
	return $pdo;
}
function texte(array $d, string $cle, int $max, bool $obligatoire = true): string {
	$v = trim((string)($d[$cle] ?? ''));
	if ($obligatoire && $v === '') erreur("Le champ $cle est obligatoire.");
	if (mb_strlen($v) > $max) erreur("Le champ $cle est trop long.");
	return $v;
}
function email_valide(array $d): string {
	$email = strtolower(texte($d, 'email', 190));
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) erreur('Adresse e-mail invalide.');
	return $email;
}
function utilisateur_connecte(): ?array {
	if (empty($_SESSION['uid'])) return null;
	$req = bdd()->prepare('SELECT id, prenom, nom, email, telephone, role FROM utilisateurs WHERE id = ?');
	$req->execute([$_SESSION['uid']]);
	$u = $req->fetch();
	if (!$u) { unset($_SESSION['uid']); return null; }
	$u['id'] = (string)$u['id'];
	return $u;
}
function exiger_connexion(): array {
	return utilisateur_connecte() ?? erreur('Vous devez etre connecte.', 401);
}
function exiger_admin(): array {
	$u = exiger_connexion();
	if ($u['role'] !== 'admin') erreur('Acces reserve aux administrateurs.', 403);
	return $u;
}
function numero_billet(): string {
	return 'GE-' . strtoupper(bin2hex(random_bytes(4)));
}
// Met les colonnes de la table billets au format attendu par le JavaScript
function format_billet(array $b): array {
	return [
		'id' => $b['numero'], 'type' => $b['type'], 'email' => $b['email'],
		'prenom' => $b['prenom'], 'nom' => $b['nom'],
		'nomPass' => $b['nom_pass'], 'nomTribune' => $b['nom_tribune'],
		'evenementId' => $b['evenement_id'] === null ? null : (string)$b['evenement_id'],
		'nomEvenement' => $b['nom_evenement'], 'dateEvenement' => $b['date_evenement'],
		'total' => (float)$b['total'], 'dateCreation' => str_replace(' ', 'T', $b['cree_le']),
	];
}
function format_evenement(array $e): array {
	$e['id'] = (string)$e['id'];
	$e['places'] = (int)$e['places'];
	$e['reservees'] = (int)($e['reservees'] ?? 0);
	$e['restantes'] = max(0, $e['places'] - $e['reservees']);
	return $e;
}

// Tarifs fixes cote serveur (on ne fait jamais confiance au prix envoye par le navigateur)
const PASSES = [
	'vendredi' => ['nom' => 'Acces Vendredi', 'prix' => 39],
	'weekend'  => ['nom' => 'Acces Samedi & Dimanche', 'prix' => 85],
	'integral' => ['nom' => 'Pass Integral 3 Jours', 'prix' => 110],
];
const TRIBUNES = [
	'pelouse'    => ['nom' => 'Pelouse / Acces libre', 'prix' => 0],
	'quais'      => ['nom' => 'Tribune des Quais', 'prix' => 24],
	'quinconces' => ['nom' => 'Tribune des Quinconces', 'prix' => 45],
	'prestige'   => ['nom' => 'Tribune Prestige', 'prix' => 85],
];

// ---------- Lecture de la requete ----------
$action = $_GET['action'] ?? '';
$methode = $_SERVER['REQUEST_METHOD'];
$donnees = [];
if ($methode === 'POST') {
	// Protection CSRF simple : un autre site ne peut pas envoyer cet en-tete sans autorisation CORS
	if (($_SERVER['HTTP_X_GUARDIA'] ?? '') !== '1') erreur('Requete refusee.', 403);
	$donnees = json_decode(file_get_contents('php://input') ?: '{}', true);
	if (!is_array($donnees)) erreur('Donnees invalides.');
}
$lecture = ['moi', 'evenements', 'mes_billets', 'admin_stats', 'admin_utilisateurs', 'admin_billets', 'admin_trafic'];
if (in_array($action, $lecture, true) ? $methode !== 'GET' : $methode !== 'POST') erreur('Methode non autorisee.', 405);

// ---------- Connexion obligatoire ----------
// Ces actions sont ouvertes aux visiteurs (consulter les evenements). Toutes les autres, dont les reservations, demandent d'etre connecte.
$publiques = ['moi', 'inscription', 'connexion', 'deconnexion', 'visite', 'evenements', 'mes_billets'];
if (!in_array($action, $publiques, true)) exiger_connexion();

// ---------- Actions ----------
switch ($action) {

	case 'moi':
		repondre(['utilisateur' => utilisateur_connecte()]);

	case 'inscription':
		$prenom = texte($donnees, 'prenom', 80);
		$nom = texte($donnees, 'nom', 80);
		$email = email_valide($donnees);
		$tel = texte($donnees, 'telephone', 30, false);
		$mdp = (string)($donnees['password'] ?? '');
		if (strlen($mdp) < 8) erreur('Le mot de passe doit avoir au moins 8 caracteres.');
		if (strlen($mdp) > 200) erreur('Mot de passe trop long.');
		try {
			$req = bdd()->prepare('INSERT INTO utilisateurs (prenom, nom, email, telephone, mot_de_passe) VALUES (?, ?, ?, ?, ?)');
			$req->execute([$prenom, $nom, $email, $tel, password_hash($mdp, PASSWORD_DEFAULT)]);
		} catch (PDOException $e) {
			if ($e->errorInfo[1] === 1062) erreur('Cette adresse e-mail est deja utilisee.', 409);
			throw $e;
		}
		session_regenerate_id(true);
		$_SESSION['uid'] = (int)bdd()->lastInsertId();
		repondre(['utilisateur' => utilisateur_connecte()], 201);

	case 'connexion':
		$email = strtolower(trim((string)($donnees['email'] ?? '')));
		$mdp = (string)($donnees['password'] ?? '');
		$req = bdd()->prepare('SELECT id, mot_de_passe FROM utilisateurs WHERE email = ?');
		$req->execute([$email]);
		$u = $req->fetch();
		if (!$u || !password_verify($mdp, $u['mot_de_passe'])) {
			usleep(500000); // ralentit les essais de mots de passe en boucle
			erreur('Adresse e-mail ou mot de passe incorrect.', 401);
		}
		session_regenerate_id(true);
		$_SESSION['uid'] = (int)$u['id'];
		repondre(['utilisateur' => utilisateur_connecte()]);

	case 'deconnexion':
		$_SESSION = [];
		session_destroy();
		repondre(['ok' => true]);

	case 'modifier_compte':
		$u = exiger_connexion();
		if ($u['role'] === 'admin') erreur('Le compte administrateur se modifie directement dans la base.', 403);
		$prenom = texte($donnees, 'prenom', 80);
		$nom = texte($donnees, 'nom', 80);
		$email = email_valide($donnees);
		$tel = texte($donnees, 'telephone', 30, false);
		$pdo = bdd();
		$pdo->beginTransaction();
		try {
			$pdo->prepare('UPDATE utilisateurs SET prenom = ?, nom = ?, email = ?, telephone = ? WHERE id = ?')
				->execute([$prenom, $nom, $email, $tel, $u['id']]);
			$pdo->prepare('UPDATE billets SET email = ? WHERE email = ?')->execute([$email, $u['email']]);
			$pdo->commit();
		} catch (PDOException $e) {
			$pdo->rollBack();
			if ($e->errorInfo[1] === 1062) erreur('Cette adresse e-mail est deja utilisee.', 409);
			throw $e;
		}
		repondre(['utilisateur' => utilisateur_connecte()]);

	case 'supprimer_compte':
		$u = exiger_connexion();
		if ($u['role'] === 'admin') erreur('Le compte administrateur ne peut pas etre supprime ici.', 403);
		$pdo = bdd();
		$pdo->beginTransaction();
		$pdo->prepare('DELETE FROM billets WHERE email = ?')->execute([$u['email']]);
		$pdo->prepare('DELETE FROM utilisateurs WHERE id = ?')->execute([$u['id']]);
		$pdo->commit();
		$_SESSION = [];
		session_destroy();
		repondre(['ok' => true]);

	case 'evenements':
		$liste = bdd()->query("SELECT e.id, e.categorie, e.titre, e.jour, e.heure, e.places, e.description, e.image,
				(SELECT COUNT(*) FROM billets b WHERE b.type = 'activite' AND b.evenement_id = e.id) AS reservees
			FROM evenements e ORDER BY e.id")->fetchAll();
		repondre(['evenements' => array_map('format_evenement', $liste)]);

	case 'evenement_sauver':
		exiger_admin();
		$categorie = (string)($donnees['categorie'] ?? '');
		$images = ['concerts' => 'evenement-photo-1.jpg', 'ateliers' => 'evenement-photo-5.jpg', 'gaming' => 'evenement-photo-4.jpg'];
		if (!isset($images[$categorie])) erreur('Categorie invalide.');
		$titre = texte($donnees, 'titre', 150);
		$jour = texte($donnees, 'jour', 60);
		$heure = texte($donnees, 'heure', 40);
		$description = texte($donnees, 'description', 2000);
		$places = (int)($donnees['places'] ?? 0);
		if ($places < 1 || $places > 1000000) erreur('Nombre de places invalide.');
		$id = (int)($donnees['id'] ?? 0);
		if ($id > 0) {
			$deja = bdd()->prepare("SELECT COUNT(*) FROM billets WHERE type = 'activite' AND evenement_id = ?");
			$deja->execute([$id]);
			$nb = (int)$deja->fetchColumn();
			if ($places < $nb) erreur("Impossible : $nb places sont deja reservees pour cet evenement.");
			$req = bdd()->prepare('UPDATE evenements SET categorie = ?, titre = ?, jour = ?, heure = ?, places = ?, description = ? WHERE id = ?');
			$req->execute([$categorie, $titre, $jour, $heure, $places, $description, $id]);
		} else {
			$req = bdd()->prepare('INSERT INTO evenements (categorie, titre, jour, heure, places, description, image) VALUES (?, ?, ?, ?, ?, ?, ?)');
			$req->execute([$categorie, $titre, $jour, $heure, $places, $description, $images[$categorie]]);
			$id = (int)bdd()->lastInsertId();
		}
		repondre(['ok' => true, 'id' => (string)$id]);

	case 'evenement_supprimer':
		exiger_admin();
		bdd()->prepare('DELETE FROM evenements WHERE id = ?')->execute([(int)($donnees['id'] ?? 0)]);
		repondre(['ok' => true]);

	case 'mes_billets':
		$u = utilisateur_connecte();
		if (!$u) repondre(['billets' => []]);
		$req = bdd()->prepare('SELECT * FROM billets WHERE email = ? ORDER BY id');
		$req->execute([$u['email']]);
		repondre(['billets' => array_map('format_billet', $req->fetchAll())]);

	
	case 'billets_course':
		$u = exiger_connexion();$passId = $donnees['passId'] ?? '';
		$tribuneId = $donnees['tribuneId'] ?? '';if (!is_string($passId) || !isset(PASSES[$passId])) {
			erreur('Pass invalide.');
		}
		if (!is_string($tribuneId) || !isset(TRIBUNES[$tribuneId])) {
			erreur('Tribune invalide.');
		}
		$pass = PASSES[$passId];
		$tribune = TRIBUNES[$tribuneId];
		$personnes = $donnees['personnes'] ?? null;if (!is_array($personnes) || count($personnes) < 1 || count($personnes) > 10) {
			erreur('Choisissez entre 1 et 10 personnes.');
		}
		// Verifier les informations des participants
		$participants = [];foreach ($personnes as $personne) {
			if (!is_array($personne)) {
				erreur('Participant invalide.');
			}
			$participants[] = [
				'prenom' => texte($personne, 'prenom', 80),
				'nom' => texte($personne, 'nom', 80),
				'telephone' => texte($personne, 'telephone', 30, false)
			];
		}
		$pdo = bdd();
		$prixBillet = $pass['prix'] + $tribune['prix'];
		$billets = [];try {
			$pdo->beginTransaction();
			$req = $pdo->prepare("INSERT INTO billets
				(numero, type, email, prenom, nom, telephone, pass_id, nom_pass,
				tribune_id, nom_tribune, prix_pass, prix_tribune, total)
				VALUES (?, 'course', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			foreach ($participants as $personne) {
				$numero = numero_billet();
				$req->execute([
					$numero,
					$u['email'],
					$personne['prenom'],
					$personne['nom'],
					$personne['telephone'],
					$passId,
					$pass['nom'],
					$tribuneId,
					$tribune['nom'],
					$pass['prix'],
					$tribune['prix'],
					$prixBillet
				]);
				$billets[] = [
					'id' => $numero,
					'prenom' => $personne['prenom'],
					'nom' => $personne['nom']
				];
			}
			$pdo->commit();
		} catch (Throwable $e) {
			if ($pdo->inTransaction()) {
				$pdo->rollBack();
			}
			error_log($e->getMessage());
			erreur('Enregistrement des billets impossible.', 500);
		}
		repondre([
			'billets' => $billets,
			'total' => $prixBillet * count($billets)
		], 201);

	case 'reserver_activite':
		$u = exiger_connexion();
		$pdo = bdd();
		$pdo->beginTransaction();
		// FOR UPDATE verrouille la ligne de l'evenement : deux clics simultanes ne peuvent pas prendre la derniere place
		$req = $pdo->prepare('SELECT id, titre, jour, heure, places FROM evenements WHERE id = ? FOR UPDATE');
		$req->execute([(int)($donnees['evenementId'] ?? 0)]);
		$evt = $req->fetch();
		if (!$evt) { $pdo->rollBack(); erreur('Evenement introuvable.', 404); }
		$deja = $pdo->prepare("SELECT 1 FROM billets WHERE type = 'activite' AND email = ? AND evenement_id = ?");
		$deja->execute([$u['email'], $evt['id']]);
		if ($deja->fetch()) { $pdo->rollBack(); erreur('Vous avez deja reserve cette activite.', 409); }
		$compte = $pdo->prepare("SELECT COUNT(*) FROM billets WHERE type = 'activite' AND evenement_id = ?");
		$compte->execute([$evt['id']]);
		if ((int)$compte->fetchColumn() >= (int)$evt['places']) { $pdo->rollBack(); erreur('Desole, cet evenement est complet.', 409); }
		$numero = numero_billet();
		$pdo->prepare("INSERT INTO billets (numero, type, email, prenom, nom, telephone, evenement_id, nom_evenement, date_evenement, total)
			VALUES (?, 'activite', ?, ?, ?, ?, ?, ?, ?, 0)")
			->execute([$numero, $u['email'], $u['prenom'], $u['nom'], $u['telephone'], $evt['id'], $evt['titre'], $evt['jour'] . ' · ' . $evt['heure']]);
		$pdo->commit();
		repondre(['ok' => true, 'numero' => $numero], 201);

	// ---------- Panneau administrateur (toutes ces actions verifient le role admin) ----------

	case 'admin_stats':
		exiger_admin();
		$pdo = bdd();
		$un = fn(string $sql) => $pdo->query($sql)->fetchColumn();
		repondre([
			'utilisateurs' => (int)$un("SELECT COUNT(*) FROM utilisateurs WHERE role = 'client'"),
			'admins'       => (int)$un("SELECT COUNT(*) FROM utilisateurs WHERE role = 'admin'"),
			'inscrits7j'   => (int)$un("SELECT COUNT(*) FROM utilisateurs WHERE cree_le >= NOW() - INTERVAL 7 DAY"),
			'billets'      => (int)$un("SELECT COUNT(*) FROM billets WHERE type = 'course'"),
			'reservations' => (int)$un("SELECT COUNT(*) FROM billets WHERE type = 'activite'"),
			'recette'      => (float)$un("SELECT COALESCE(SUM(total), 0) FROM billets"),
			'evenements'   => (int)$un('SELECT COUNT(*) FROM evenements'),
			'parPass'      => $pdo->query("SELECT nom_pass AS nom, COUNT(*) AS nombre FROM billets WHERE type = 'course' GROUP BY nom_pass ORDER BY nombre DESC")->fetchAll(),
			'topActivites' => $pdo->query("SELECT nom_evenement AS nom, COUNT(*) AS nombre FROM billets WHERE type = 'activite' GROUP BY nom_evenement ORDER BY nombre DESC LIMIT 5")->fetchAll(),
			'derniers'     => $pdo->query('SELECT prenom, nom, email, role, cree_le FROM utilisateurs ORDER BY id DESC LIMIT 5')->fetchAll(),
		]);

	// ---------- Mesure d'audience (anonyme : pas de cookie, IP jamais enregistree) ----------
	case 'visite':
		$pages = ['accueil', 'programme', 'evenements', 'billetterie', 'connexion', 'inscription', 'compte'];
		$page = (string)($donnees['page'] ?? '');
		$ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 400);
		$moi = utilisateur_connecte();
		// on ignore les pages inconnues, les robots et les visites des admins
		if (!in_array($page, $pages, true) || preg_match('/bot|crawl|spider|slurp|curl|wget|python|headless/i', $ua) || ($moi && $moi['role'] === 'admin')) repondre(['ok' => true]);
		$ip = $_SERVER['REMOTE_ADDR'] ?? '';
		if (in_array($ip, ['127.0.0.1', '::1'], true) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
		$sel = (require __DIR__ . '/config.php')['mot_de_passe'];
		$visiteur = substr(hash('sha256', $ip . '|' . $ua . '|' . date('Y-m-d') . '|' . $sel), 0, 16);
		$source = 'Direct';
		$hoteRef = parse_url((string)($donnees['referrer'] ?? ''), PHP_URL_HOST);
		if ($hoteRef && $hoteRef !== ($_SERVER['HTTP_HOST'] ?? '')) $source = substr(preg_replace('/^www\./', '', $hoteRef), 0, 120);
		$appareil = preg_match('/iPad|Tablet/i', $ua) ? 'tablette' : (preg_match('/Mobile|Android|iPhone/i', $ua) ? 'mobile' : 'ordinateur');
		$navigateur = match (true) {
			str_contains($ua, 'Edg/') => 'Edge', str_contains($ua, 'OPR/') => 'Opera', str_contains($ua, 'Brave') => 'Brave',
			str_contains($ua, 'Firefox/') => 'Firefox', str_contains($ua, 'Chrome/') => 'Chrome', str_contains($ua, 'Safari/') => 'Safari',
			default => 'Autre',
		};
		try {
			bdd()->prepare('INSERT INTO visites (visiteur, page, source, appareil, navigateur) VALUES (?, ?, ?, ?, ?)')
				->execute([$visiteur, $page, $source, $appareil, $navigateur]);
		} catch (PDOException $e) { /* table absente : la mesure d'audience est simplement desactivee */ }
		repondre(['ok' => true]);

	case 'admin_trafic':
		exiger_admin();
		$jours = in_array((int)($_GET['jours'] ?? 30), [7, 30, 90], true) ? (int)$_GET['jours'] : 30;
		$pdo = bdd();
		$debut = date('Y-m-d', strtotime('-' . ($jours - 1) . ' days'));
		// une ligne par jour, meme les jours sans donnees
		$serie = [];
		for ($t = strtotime($debut); $t <= strtotime('today'); $t += 86400) $serie[date('Y-m-d', $t)] = ['jour' => date('Y-m-d', $t), 'vues' => 0, 'visiteurs' => 0, 'inscriptions' => 0, 'billets' => 0, 'recette' => 0];
		$parJour = function (string $sql, array $champs) use ($pdo, $debut, &$serie) {
			$req = $pdo->prepare($sql); $req->execute([$debut]);
			foreach ($req->fetchAll() as $l) if (isset($serie[$l['jour']])) foreach ($champs as $c) $serie[$l['jour']][$c] = (float)$l[$c];
		};
		$parJour("SELECT DATE(cree_le) AS jour, COUNT(*) AS inscriptions FROM utilisateurs WHERE cree_le >= ? GROUP BY jour", ['inscriptions']);
		$parJour("SELECT DATE(cree_le) AS jour, COUNT(*) AS billets, SUM(total) AS recette FROM billets WHERE type = 'course' AND cree_le >= ? GROUP BY jour", ['billets', 'recette']);
		$top = function (string $colonne, int $limite = 8) use ($pdo, $debut) {
			$req = $pdo->prepare("SELECT $colonne AS nom, COUNT(*) AS nombre FROM visites WHERE cree_le >= ? GROUP BY $colonne ORDER BY nombre DESC LIMIT $limite");
			$req->execute([$debut]); return $req->fetchAll();
		};
		$un = function (string $sql, array $p = []) use ($pdo) { $r = $pdo->prepare($sql); $r->execute($p); return (int)$r->fetchColumn(); };
		$migration = false; $res = ['pages' => [], 'sources' => [], 'appareils' => [], 'navigateurs' => [], 'heures' => array_fill(0, 24, 0)];
		$tot = ['vues' => 0, 'visiteurs' => 0, 'enLigne' => 0, 'vuesJour' => 0, 'visiteursJour' => 0];
		try {
			$parJour("SELECT DATE(cree_le) AS jour, COUNT(*) AS vues, COUNT(DISTINCT visiteur) AS visiteurs FROM visites WHERE cree_le >= ? GROUP BY jour", ['vues', 'visiteurs']);
			$res['pages'] = $top('page'); $res['sources'] = $top('source'); $res['appareils'] = $top('appareil', 3); $res['navigateurs'] = $top('navigateur', 6);
			$req = $pdo->prepare('SELECT HOUR(cree_le) AS h, COUNT(*) AS n FROM visites WHERE cree_le >= ? GROUP BY h'); $req->execute([$debut]);
			foreach ($req->fetchAll() as $l) $res['heures'][(int)$l['h']] = (int)$l['n'];
			$tot['vues'] = $un('SELECT COUNT(*) FROM visites WHERE cree_le >= ?', [$debut]);
			$tot['visiteurs'] = $un('SELECT COUNT(DISTINCT visiteur, DATE(cree_le)) FROM visites WHERE cree_le >= ?', [$debut]);
			$tot['enLigne'] = $un('SELECT COUNT(DISTINCT visiteur) FROM visites WHERE cree_le >= NOW() - INTERVAL 5 MINUTE');
			$tot['vuesJour'] = $un('SELECT COUNT(*) FROM visites WHERE cree_le >= CURDATE()');
			$tot['visiteursJour'] = $un('SELECT COUNT(DISTINCT visiteur) FROM visites WHERE cree_le >= CURDATE()');
		} catch (PDOException $e) {
			if ($e->errorInfo[1] !== 1146) throw $e;
			$migration = true; // table visites pas encore creee
		}
		$tot['inscriptions'] = $un('SELECT COUNT(*) FROM utilisateurs WHERE cree_le >= ?', [$debut]);
		$tot['billets'] = $un("SELECT COUNT(*) FROM billets WHERE type = 'course' AND cree_le >= ?", [$debut]);
		repondre(['jours' => $jours, 'migrationRequise' => $migration, 'totaux' => $tot, 'serie' => array_values($serie)] + $res);

	case 'admin_utilisateur_creer':
		exiger_admin();
		$prenom = texte($donnees, 'prenom', 80);
		$nom = texte($donnees, 'nom', 80);
		$email = email_valide($donnees);
		$tel = texte($donnees, 'telephone', 30, false);
		$role = ($donnees['role'] ?? '') === 'admin' ? 'admin' : 'client';
		$mdp = (string)($donnees['password'] ?? '');
		if (strlen($mdp) < ($role === 'admin' ? 12 : 8)) erreur($role === 'admin' ? 'Mot de passe admin : 12 caracteres minimum.' : 'Le mot de passe doit avoir au moins 8 caracteres.');
		try {
			bdd()->prepare('INSERT INTO utilisateurs (prenom, nom, email, telephone, mot_de_passe, role) VALUES (?, ?, ?, ?, ?, ?)')
				->execute([$prenom, $nom, $email, $tel, password_hash($mdp, PASSWORD_DEFAULT), $role]);
		} catch (PDOException $e) {
			if ($e->errorInfo[1] === 1062) erreur('Cette adresse e-mail est deja utilisee.', 409);
			throw $e;
		}
		repondre(['ok' => true], 201);

	case 'admin_utilisateurs':
		exiger_admin();
		$liste = bdd()->query('SELECT u.id, u.prenom, u.nom, u.email, u.telephone, u.role, u.cree_le,
				(SELECT COUNT(*) FROM billets b WHERE b.email = u.email) AS nb_billets,
				(SELECT COALESCE(SUM(total), 0) FROM billets b WHERE b.email = u.email) AS depense
			FROM utilisateurs u ORDER BY u.id DESC')->fetchAll();
		foreach ($liste as &$u) { $u['id'] = (string)$u['id']; $u['nb_billets'] = (int)$u['nb_billets']; $u['depense'] = (float)$u['depense']; }
		repondre(['utilisateurs' => $liste]);

	case 'admin_utilisateur_modifier':
		$moi = exiger_admin();
		$id = (int)($donnees['id'] ?? 0);
		$cible = bdd()->prepare('SELECT id, email, role FROM utilisateurs WHERE id = ?');
		$cible->execute([$id]);
		$cible = $cible->fetch() ?: erreur('Utilisateur introuvable.', 404);
		$prenom = texte($donnees, 'prenom', 80);
		$nom = texte($donnees, 'nom', 80);
		$email = email_valide($donnees);
		$tel = texte($donnees, 'telephone', 30, false);
		$role = ($donnees['role'] ?? '') === 'admin' ? 'admin' : 'client';
		if ((string)$id === $moi['id'] && $role !== 'admin') erreur('Vous ne pouvez pas retirer votre propre role admin.', 403);
		$mdp = (string)($donnees['password'] ?? '');
		if ($mdp !== '' && strlen($mdp) < 8) erreur('Le nouveau mot de passe doit avoir au moins 8 caracteres.');
		$pdo = bdd();
		$pdo->beginTransaction();
		try {
			$pdo->prepare('UPDATE utilisateurs SET prenom = ?, nom = ?, email = ?, telephone = ?, role = ? WHERE id = ?')
				->execute([$prenom, $nom, $email, $tel, $role, $id]);
			if ($mdp !== '') $pdo->prepare('UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?')->execute([password_hash($mdp, PASSWORD_DEFAULT), $id]);
			$pdo->prepare('UPDATE billets SET email = ? WHERE email = ?')->execute([$email, $cible['email']]);
			$pdo->commit();
		} catch (PDOException $e) {
			$pdo->rollBack();
			if ($e->errorInfo[1] === 1062) erreur('Cette adresse e-mail est deja utilisee.', 409);
			throw $e;
		}
		repondre(['ok' => true]);

	case 'admin_utilisateur_supprimer':
		$moi = exiger_admin();
		$id = (int)($donnees['id'] ?? 0);
		if ((string)$id === $moi['id']) erreur('Vous ne pouvez pas supprimer votre propre compte.', 403);
		$req = bdd()->prepare('SELECT email FROM utilisateurs WHERE id = ?');
		$req->execute([$id]);
		$email = $req->fetchColumn();
		if ($email === false) erreur('Utilisateur introuvable.', 404);
		$pdo = bdd();
		$pdo->beginTransaction();
		$pdo->prepare('DELETE FROM billets WHERE email = ?')->execute([$email]);
		$pdo->prepare('DELETE FROM utilisateurs WHERE id = ?')->execute([$id]);
		$pdo->commit();
		repondre(['ok' => true]);

	case 'admin_billets':
		exiger_admin();
		$liste = bdd()->query('SELECT * FROM billets ORDER BY id DESC LIMIT 500')->fetchAll();
		repondre(['billets' => array_map('format_billet', $liste)]);

	case 'admin_billet_supprimer':
		exiger_admin();
		bdd()->prepare('DELETE FROM billets WHERE numero = ?')->execute([(string)($donnees['numero'] ?? '')]);
		repondre(['ok' => true]);

	default:
		erreur('Action inconnue.', 404);
}
