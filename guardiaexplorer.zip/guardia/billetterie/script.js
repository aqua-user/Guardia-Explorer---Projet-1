
/* Billetterie : choix du pass, tribune, participants et confirmation. */

const passes = [
	{ id: 'vendredi', nom: 'Acces Vendredi', prix: 39, description: 'Essais et concert d ouverture' },
	{ id: 'weekend', nom: 'Acces Samedi & Dimanche', prix: 85, description: 'Qualifications, course sprint et Grand Prix' },
	{ id: 'integral', nom: 'Pass Integral 3 Jours', prix: 110, description: 'Toutes les sessions et animations' }
];

const tribunes = [
	{ id: 'pelouse', nom: 'Pelouse / Acces libre', prix: 0, description: 'Vue depuis les espaces libres du circuit' },
	{ id: 'quais', nom: 'Tribune des Quais', prix: 24, description: 'Vue sur la longue ligne droite' },
	{ id: 'quinconces', nom: 'Tribune des Quinconces', prix: 45, description: 'Vue sur l enchainement des virages' },
	{ id: 'prestige', nom: 'Tribune Prestige', prix: 85, description: 'Placement privilegie a proximite du paddock' }
];

let etape = 1;
let pass = passes.find(p => p.id === new URLSearchParams(location.search).get('pass')) || null;
let tribune = null;
let quantite = 1;
let quantiteAffichee = 1;
let commande = null;

// Affiche les choix de pass et de tribune.
function dessinerChoix(id, liste, selection) {
	document.getElementById(id).innerHTML = liste.map(item => `
		<label class="option">
			<input type="radio" name="${id}" value="${item.id}" ${item === selection ? 'checked' : ''}>
			<div>
				<strong>${item.nom}</strong>
				<small>${item.description}</small>
			</div>
			<em>${GE.argent(item.prix)}</em>
		</label>
	`).join('');
}

// Calcule et affiche le prix total pour tous les participants.
function resume() {
	const prixPass = pass ? pass.prix : 0;
	const prixTribune = tribune ? tribune.prix : 0;
	const total = (prixPass + prixTribune) * quantite;

	document.getElementById('resume-billet').innerHTML = `
		<div class="resume-ligne"><span>Pass</span><b>${pass ? pass.nom : 'Non choisi'}</b></div>
		<div class="resume-ligne"><span>Tribune</span><b>${tribune ? tribune.nom : 'Non choisie'}</b></div>
		<div class="resume-ligne"><span>Supplément tribune / billet</span><b>${GE.argent(prixTribune)}</b></div>
		<div class="resume-ligne"><span>Nombre de billets</span><b>${quantite}</b></div>
		<div class="resume-total">TOTAL : ${GE.argent(total)}</div>
		<small>Aucun paiement réel, les montants sont indicatifs.</small>
	`;
}

// Crée un formulaire prénom/nom pour chaque personne supplémentaire.
function afficherAutresPersonnes() {
	if (quantiteAffichee === quantite) return;

	const conteneur = document.getElementById('autres-personnes');
	const anciennesValeurs = {};

	conteneur.querySelectorAll('input').forEach(champ => {
		anciennesValeurs[champ.id] = champ.value;
	});

	let html = '';
	for (let i = 2; i <= quantite; i++) {
		html += `
			<fieldset class="personne">
				<legend>PERSONNE ${i}</legend>
				<div class="champs-2">
					<div class="champ">
						<label for="prenom-${i}">Prénom *</label>
						<input id="prenom-${i}" maxlength="50" required>
					</div>
					<div class="champ">
						<label for="nom-${i}">Nom *</label>
						<input id="nom-${i}" maxlength="50" required>
					</div>
				</div>
			</fieldset>
		`;
	}

	conteneur.innerHTML = html;
	conteneur.querySelectorAll('input').forEach(champ => {
		champ.value = anciennesValeurs[champ.id] || '';
	});
	quantiteAffichee = quantite;
}

// Affiche une étape et met à jour la barre de progression.
function afficherEtape(numero) {
	etape = numero;

	for (let i = 1; i <= 4; i++) {
		document.getElementById('etape-' + i).hidden = i !== numero;
	}

	document.querySelectorAll('#etapes span').forEach((span, index) => {
		span.classList.toggle('en-cours', index === numero - 1);
		span.classList.toggle('terminee', index < numero - 1);
	});

	if (numero === 3) {
		afficherAutresPersonnes();
		const utilisateur = GE.utilisateur();
		if (utilisateur) {
			for (const id of ['prenom', 'nom', 'email', 'telephone']) {
				const champ = document.getElementById(id);
				if (!champ.value || id === 'email') champ.value = utilisateur[id] || '';
			}
		}
	}

	resume();
	window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Prépare les options et le formulaire.
dessinerChoix('choix-pass', passes, pass);
dessinerChoix('choix-tribune', tribunes, tribune);
document.getElementById('suivant-1').disabled = !pass;
document.getElementById('suivant-2').disabled = !tribune;
resume();

// Charge les informations du compte dès qu'elles sont disponibles.
GE.pret.then(() => {
	if (etape === 3) afficherEtape(3);
});

// Choix du pass.
document.getElementById('choix-pass').addEventListener('change', event => {
	pass = passes.find(p => p.id === event.target.value) || null;
	document.getElementById('suivant-1').disabled = !pass;
	resume();
});

// Choix de la tribune.
document.getElementById('choix-tribune').addEventListener('change', event => {
	tribune = tribunes.find(t => t.id === event.target.value) || null;
	document.getElementById('suivant-2').disabled = !tribune;
	resume();
});

// Quantité entre 1 et 10 billets.
document.getElementById('quantite').addEventListener('change', event => {
	quantite = Math.max(1, Math.min(10, Math.round(Number(event.target.value) || 1)));
	event.target.value = quantite;
	resume();
});

// Navigation entre les étapes.
document.getElementById('suivant-1').addEventListener('click', () => {
	if (pass) afficherEtape(2);
});
document.getElementById('suivant-2').addEventListener('click', () => {
	if (tribune) afficherEtape(3);
});
document.getElementById('retour-2').addEventListener('click', () => afficherEtape(1));
document.getElementById('retour-3').addEventListener('click', () => afficherEtape(2));

// Envoie une seule commande contenant tous les participants.
document.getElementById('formulaire-billet').addEventListener('submit', async event => {
	event.preventDefault();
	const formulaire = event.target;

	if (!pass || !tribune || !formulaire.reportValidity()) return;

	const utilisateur = await GE.pret;
	if (!utilisateur) {
		GE.notification('Connectez-vous pour réserver des billets.');
		return;
	}

	const personnes = [{
		prenom: document.getElementById('prenom').value.trim(),
		nom: document.getElementById('nom').value.trim(),
		telephone: document.getElementById('telephone').value.trim()
	}];

	for (let i = 2; i <= quantite; i++) {
		personnes.push({
			prenom: document.getElementById('prenom-' + i).value.trim(),
			nom: document.getElementById('nom-' + i).value.trim(),
			telephone: ''
		});
	}

	if (personnes.some(p => !p.prenom || !p.nom)) {
		GE.notification('Indiquez le prénom et le nom de chaque personne.');
		return;
	}

	const bouton = formulaire.querySelector('[type="submit"]');
	bouton.disabled = true;

	try {
		// Cette action doit exister dans api/api.php (case 'billets_course').
		commande = await GE.api('billets_course', {
			passId: pass.id,
			tribuneId: tribune.id,
			personnes: personnes
		});

		let html = '<h3>VOS BILLETS</h3>';
		for (const billet of commande.billets) {
			html += `
				<p>
					<strong>${GE.propre(billet.prenom)} ${GE.propre(billet.nom)}</strong><br>
					Numéro : ${GE.propre(billet.id)}
				</p>
			`;
		}

		html += `
			<p><strong>Pass :</strong> ${GE.propre(pass.nom)}</p>
			<p><strong>Tribune :</strong> ${GE.propre(tribune.nom)}</p>
			<p><strong>Nombre de billets :</strong> ${commande.billets.length}</p>
			<p><strong>Total indicatif :</strong> ${GE.argent(commande.total)}</p>
			<p><strong>E-mail du compte :</strong> ${GE.propre(utilisateur.email)}</p>
			<p class="muted">Les billets ont été enregistrés. Retrouvez-les dans Mon compte.</p>
		`;

		document.getElementById('confirmation-details').innerHTML = html;
		afficherEtape(4);
	} catch (erreur) {
		GE.notification(erreur.message);
	} finally {
		bouton.disabled = false;
	}
});
