/* Connexion (verifiee par le serveur) */
const formulaire = document.getElementById('formulaire-connexion');
const erreur = document.getElementById('connexion-erreur');
// Garde la page demandee pour y revenir, y compris si on passe par "Creer mon compte"
const retour = new URLSearchParams(location.search).get('retour');
if (retour) document.querySelectorAll('a[href="../inscription/index.html"]').forEach(a => a.href += '?retour=' + encodeURIComponent(retour));
if (retour) document.getElementById('connexion-erreur').textContent = 'Connectez-vous ou créez un compte pour accéder à cette page.';
GE.pret.then(() => { if (GE.utilisateur()) location.href = GE.pageRetour('accueil'); });

formulaire.addEventListener('submit', async e => {
	e.preventDefault();
	erreur.textContent = '';
	if (!document.getElementById('humain').checked) return;
	try {
		const u = await GE.connecter(document.getElementById('email').value, document.getElementById('password').value);
		location.href = GE.pageRetour(u.role === 'admin' ? 'admin' : 'accueil');
	} catch (err) { erreur.textContent = err.message; }
});
