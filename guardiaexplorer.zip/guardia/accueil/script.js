
/* Accueil : compteur et aperçu du Fan Village. */

// Actualise le compte à rebours
function actualiserCompteARebours() {
	const distance = Math.max(0, new Date(GE.dateCourse) - Date.now());

	const jours = Math.floor(distance / 86400000);
	const heures = Math.floor(distance / 3600000) % 24;
	const minutes = Math.floor(distance / 60000) % 60;
	const secondes = Math.floor(distance / 1000) % 60;

	const valeurs = { jours, heures, minutes, secondes };

	for (const id in valeurs) {
		document.getElementById(id).textContent =
			String(valeurs[id]).padStart(2, '0');
	}
}

// Crée la carte HTML d'un événement
function creerCarteEvenement(evenement) {
	return `
		<article class="carte">
			<img class="image-carte" src="../images/${GE.propre(evenement.image)}" alt="Illustration de l'evenement">
			<span class="surtitre">${GE.propre(evenement.categorie)} • ${GE.propre(evenement.jour)}</span>
			<h3>${GE.propre(evenement.titre)}</h3>
			<p>${GE.propre(evenement.description)}</p>
			<small class="mono muted">${evenement.restantes ? evenement.restantes + ' PLACES RESTANTES' : 'COMPLET'}</small>
			<a href="../evenements/index.html#evenement-${GE.propre(evenement.id)}" class="lien-texte">DECOUVRIR L'EVENEMENT</a>
		</article>`;
}

// Affiche les 3 événements les plus récents
function afficherEvenements(liste) {
	const evenements = [...(liste || [])];

	evenements.sort((a, b) => Number(b.id) - Number(a.id));

	const derniersEvenements = evenements.slice(0, 3);
	let html = '';

	for (const evenement of derniersEvenements) {
		html += creerCarteEvenement(evenement);
	}

	document.getElementById('apercu-evenements').innerHTML = html;
}

// Charge les événements
GE.pret
	.then(() => GE.evenements())
	.then(afficherEvenements)
	.catch(erreur => {
		document.getElementById('apercu-evenements').innerHTML =
			`<p class="message">${GE.propre(erreur.message)}</p>`;
	});

// Démarre le compte à rebours
actualiserCompteARebours();
setInterval(actualiserCompteARebours, 1000);
